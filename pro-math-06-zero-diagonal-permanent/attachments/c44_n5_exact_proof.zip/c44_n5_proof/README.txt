五阶零对角双随机矩阵 permanent 下界：精确证书
================================================

日期：2026-11-18

结论
----
若 A 是 5×5 非负双随机矩阵，且 a_ii=0，令 U=(J-I)/4，则

    per(A) >= 11/256 + ||A-U||_F^2 / 6400.

因此原题的不等式成立，且等号当且仅当 A=U。

验证（无需优化器，无需网络，无需第三方 Python 包）
------------------------------------------------
在本目录执行：

    python verify.py certificate.json

程序完全使用整数运算。它核对：矩阵坐标；44 个错排；240 个群元素；
各次齐次不变多项式空间的维数；独立取值点的满秩证据；精确多项式
恒等式；证书整数矩阵的全部 26 个正顺序主子式。

另一种完整的多项式核验
----------------------
如已安装 NumPy，可再执行：

    python verify.py --full certificate.json

--full 在 11 元五次多项式的全部 4,368 个单纯形格点上检查精确恒等式。
程序中的数组运算均为整数运算，并明确检查防止整数溢出的界。
这组点具有唯一插值性，因此它检验的是恒等式，而非随机数值抽样。
完整模式在本次环境使用单核运行约 2 秒。

第二个独立实现（同样只需 Python 标准库）：

    python verify_independent.py certificate.json

请保持 Python 默认的断言开启状态，不要使用 -O 或 -OO。

内容
----
PROOF_zh.txt            完整数学说明：证书如何推出全局不等式与等号唯一性。
certificate.json       26×26 有理 Gram 矩阵，351 个整数上三角系数及其公分母。
verify.py              独立的整数核验程序，默认仅依赖 Python 标准库。
verify_independent.py  第二个独立核验实现，使用显式特征标公式。
verification.txt       对交付文件实际运行验证得到的输出。
reproduce/             证书发现过程的脚本和数值检查点；证明核验不依赖它们。

certificate.json 的 SHA-256：
f5af5642870922ec3f79e3845483d7cbe290b6f483cdc095624e5097cbc5ad76

证书发现过程的复跑
------------------
进入 reproduce 目录。需要 numpy、scipy、sympy、cvxpy 和 Clarabel。
原始求解限制每个库为单线程。典型命令：

    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python sos_search.py
    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python rationalize.py
    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python analytic/exact26.py

其中第一步重新建立 77 维的数值 Gram 证书，第二步产生一个有理证书，
第三步在固定的 26 个单项式上重新求解并有理化。
也可以使用包内 sos_work 的数值检查点，直接执行第三步。
不同优化器版本可能产生不同但有效的系数；请对重新产生的 JSON 再运行
verify.py。对固定的交付证书，验证结果不依赖浮点求解器及其版本。

原题及文献背景
--------------
https://yair-lavi.com/mincs-list/conjecture-44/index.html
London and Minc (1989): DOI 10.1080/03081088908817922
Burghduff (1995): DOI 10.1080/03081089508818428

这些引用用于核对原题与既有工作范围。本文的五阶证书证明不依赖
文献中的局部极小性、边界估计或数值网格结果。
