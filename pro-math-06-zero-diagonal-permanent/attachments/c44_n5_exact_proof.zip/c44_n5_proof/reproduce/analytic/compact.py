import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1';os.environ['RAYON_NUM_THREADS']='1'
import numpy as np,scipy.linalg as la
import cvxpy as cp
from itertools import combinations_with_replacement,permutations
st=np.load('sos_work/basis.npz'); P=st['P'];g=st['g'];dr=st['dr'];L=st['L']; ei={tuple(x):i for i,x in enumerate(st['edges'])}; qi=st['qi'];qj=st['qj'];qw=st['qweight']; data=np.load('sos_work/constraints.npz'); A=data['A'].reshape(-1,77,77); b=data['b'].copy(); Q=np.load('sos_work/Q.npy');b-=.01*np.einsum('ijj->i',A[:,:11,:11]); n=11
# Natural monomials H[e],H[e] H[f]; evaluated in orth coordinates
pairs=list(combinations_with_replacement(range(20),2));dlin=P.T
qfull=np.array([(P[i,qi]*P[j,qj]+P[i,qj]*P[j,qi])*qw/2 for i,j in pairs]).T
D=np.zeros((77,230));D[:11,:20]=dlin; D[11:,20:]=qfull
piv=np.array([6,7,9,10,11,13,14,15,17,18,19]); lin=list(piv)
assert np.array_equal(L[piv],np.eye(11))
def solv(D1, ret=False):
 U,s,V=la.svd(D1,full_matrices=False); k=(s>s[0]*1e-10).sum();U=U[:,:k];E=U.T@A@U
 if np.linalg.matrix_rank(E.reshape(34,-1),1e-7)<34:return (-1000,None) if ret else -1000
 X=cp.Variable((k,k),symmetric=True);t=cp.Variable();pr=cp.Problem(cp.Maximize(t),[X>>t*np.eye(k),E.reshape(34,-1)@cp.vec(X,order='C')==b]);pr.solve(solver='CLARABEL',max_iter=80,verbose=False,tol_gap_abs=1e-7,tol_feas=1e-7,tol_gap_rel=1e-7);eps=t.value if t.value is not None else -1e9
 if ret:return eps,(U,X.value)
 return eps
def choose(PS,k):
 # greedy fit high rank of Q using normalized candidate dictionary
 rem=PS.copy();v=qfull/np.linalg.norm(qfull,axis=0);idx=[]
 for j in range(k):
  residual=np.linalg.norm(rem.T@v,axis=0); z=np.argmax(residual);idx.append(z); w=v[:,z]; u=w/la.norm(w);rem-=np.outer(u,u@rem);vw=u@v;v-=np.outer(u,vw); norms=la.norm(v,axis=0);norms[norms<1e-8]=1;v/=norms;v[:,z]=0
 return idx
if __name__=='__main__':
 ev,us=la.eigh(Q[11:,11:]);ms=np.maximum(ev-.0315,0);K=us*np.sqrt(ms);order=choose(K,50)
 for k in [10,15,20,25,30,35,40,45,50]:
  idx=lin+[20+i for i in order[:k]];print(k,solv(D[:,idx]),idx,flush=True)
