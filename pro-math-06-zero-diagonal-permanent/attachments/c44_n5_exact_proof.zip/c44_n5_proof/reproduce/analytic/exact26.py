from compact import *
import sympy as sp
import json,sys
from pathlib import Path
from itertools import combinations,combinations_with_replacement
from math import comb,gcd
from functools import reduce
from scipy import linalg
out=Path('analytic');ids=list(map(int,json.loads((out/'feature.json').read_text())));f=[(i,) if i<20 else pairs[i-20] for i in ids];m=len(f);dl=sum(len(a)==1 for a in f);assert all(len(a)==1 for a in f[:dl]) and all(len(a)==2 for a in f[dl:]);qi1,qj1=np.triu_indices(m);doubling=1+(qi1!=qj1).astype(int)
def specs(x):
 h=L@x;hs=h[g];v=np.column_stack([hs[:,a[0]] if len(a)==1 else hs[:,a[0]]*hs[:,a[1]] for a in f]); linear=v[:,:dl];v2=v[:,dl:];e=hs[:,0]; grams=np.zeros((4,m,m),dtype=np.int64)
 grams[0,:dl,:dl]=linear.T@linear
 grams[1,:dl,:dl]=linear.T@(e[:,None]*linear);grams[1,:dl,dl:]=linear.T@v2
 grams[2,:dl,dl:]=linear.T@(e[:,None]*v2); grams[2,dl:,dl:]=v2.T@v2
 grams[3,dl:,dl:]=v2.T@(e[:,None]*v2)
 rhs=np.array([240*sum(np.prod(h[dr[:,s]],axis=1).sum() for s in combinations(range(5),k)) for k in range(2,6)],dtype=np.int64); rhs=rhs*100;rhs[0]-=240*(h@h)
 return grams[:,qi1,qj1]*doubling,rhs

def exactgen():
 eps,(U,X)=solv(D[:,ids],True);Z=la.pinv(U.T@D[:,ids]);Qn=Z@X@Z.T;Qn=(Qn+Qn.T)/2;print('float eps, min natural',eps,np.linalg.eigvalsh(Qn).min(),flush=True)
 rng=np.random.default_rng(301);samples=list(np.eye(11,dtype=np.int64));
 for i in range(140):
  x=np.zeros(11,dtype=np.int64);ix=rng.choice(11,2+i//40,replace=False);x[ix]=rng.choice([-1,1],len(ix));samples.append(x)
 rr=[specs(x) for x in samples];am=np.array([t[0] for t in rr]);av=np.array([t[1] for t in rr]);C=[];v=[]
 for j,r in enumerate([2,3,11,18]):
  aj=am[:,j,:];norm=la.norm(aj,axis=1);jj=la.qr((aj/np.maximum(norm,1)[:,None]).T,mode='economic',pivoting=True)[2][:r];C.extend(aj[jj]);v.extend(av[jj,j]);
 C=np.array(C);v=np.array(v);cscale=la.norm(C,axis=1);col=la.qr(C/cscale[:,None],mode='economic',pivoting=True)[2][:34];sub=sp.Matrix(C[:,col]);inv=sub.inv();print('rank',34,flush=True)
 for base in [100,1000,10000]:
  V=np.rint(Qn[qi1,qj1]*base).astype(np.int64);r=sp.Matrix((base//100)*v-C@V);corr=inv*r;qq=list(map(sp.Rational,V.tolist()));
  for j,tx in zip(col,corr):qq[j]+=tx
  denom=sp.ilcm(*[v.q for v in qq]);dim=int(denom)*base;nums=[int(q*denom) for q in qq];gcd0=reduce(gcd,nums,dim);dim//=gcd0;nums=[z//gcd0 for z in nums];Qq=np.zeros((m,m));Qq[qi1,qj1]=np.array(nums)/float(dim);Qq[qj1,qi1]=Qq[qi1,qj1];minev=la.eigvalsh(Qq).min();print('denom, min eig',dim,minev,flush=True)
  if minev<=0:continue
  M=[[0]*m for _ in range(m)];
  for i,j,q in zip(qi1,qj1,nums):M[i][j]=q;M[j][i]=q
  p=1;piv=[]
  for i in range(m):
   v0=M[i][i];assert v0>0;piv.append(v0)
   for j in range(i+1,m):
    for k in range(i+1,m):
     num=M[j][k]*v0-M[j][i]*M[i][k];assert num%p==0;M[j][k]=num//p
   p=v0
  assert max(abs(100*(am.astype(object)@np.array(nums,dtype=object))-dim*av.astype(object)).ravel())==0
  data=dict(description='Order five Minc Conjecture 44, sparse monomial Gram with +||H||^2/100',edges=st['edges'].tolist(),linear_dimension=dl,dimension=m,features=[list(map(int,t)) for t in f],denominator=str(dim),upper_numerators=[str(i) for i in nums],L=L.tolist(),margin=[1,100]);(out/'cert26.json').write_text(json.dumps(data,separators=(',',':'))+'\n');print('EXACT all leading minors; sample residuals zero',flush=True);break

def simplex(n,total):
 if n==1:yield (total,);return
 for k in range(total+1):
  for xx in simplex(n-1,total-k):yield (k,)+xx

def full():
 c=json.loads((out/'cert26.json').read_text());dd=int(c['denominator']);num=np.array([int(x) for x in c['upper_numerators']],dtype=object)*doubling.astype(object);count=0
 for t in range(6):
  for x in simplex(11,t):
   h=L@x;hg=h[g];z=np.column_stack([hg[:,a[0]] if len(a)==1 else hg[:,a[0]]*hg[:,a[1]] for a in f]);gram=z.T@((1+hg[:,0])[:,None]*z);p=(1+h[dr]).prod(axis=1).sum()-44;q=int(num@gram[qi1,qj1].astype(object));assert (240*int(p)*100-240*int(h@h))*dd==100*q;count+=1
 print('EXACT FULL',count,flush=True)
if __name__=='__main__':exactgen();full()
