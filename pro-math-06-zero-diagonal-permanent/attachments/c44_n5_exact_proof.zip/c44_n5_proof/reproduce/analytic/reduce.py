from compact import *
import json,sys
r=np.random.default_rng(435); ev,us=la.eigh(Q[11:,11:]);ms=np.maximum(ev-.0315,0);K=us*np.sqrt(ms);order=choose(K,50)
idx=lin+[20+i for i in order[:25]]
count=0
step=True
while step:
 step=False;best=(0,None)
 for x in r.permutation(idx):
  i2=[j for j in idx if j!=x]
  eps=solv(D[:,i2]);count+=1
  if eps>best[0]:best=eps,x
 if best[1] is not None and best[0]>.001:
  idx.remove(best[1]);step=True;print(len(idx),int(best[1]),best[0],count,flush=True);open('analytic/feature.json','w').write(json.dumps(list(map(int,idx))))
print('final',list(map(int,idx)),flush=True)
