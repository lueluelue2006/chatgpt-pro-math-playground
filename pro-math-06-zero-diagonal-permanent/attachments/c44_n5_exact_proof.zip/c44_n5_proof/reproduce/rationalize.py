import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import numpy as np
import scipy.linalg as la
import sympy as sp
import itertools as it
import json,math,time
from pathlib import Path

OUT=Path('sos_work')
basis=np.load(OUT/'basis.npz')
L,P,g,dr=[basis[k] for k in ['L','P','g','dr']]
edges=[tuple(map(int,a)) for a in basis['edges']]
dim=11;d=77
qpairs=list(it.combinations_with_replacement(range(dim),2))
qi,qj=basis['qi'],basis['qj']
ui,uj=np.triu_indices(d)
fac=np.where(ui==uj,1,2)
free=[int(np.flatnonzero(np.all(L==np.eye(dim,dtype=int)[j],axis=1))[0]) for j in range(dim)]
def coeff(h):
 c=np.ones((44,1),dtype=np.int64)
 for k in range(5):
  n=np.zeros((44,c.shape[1]+1),dtype=np.int64); n[:,:-1]+=c; n[:,1:]+=c*h[dr[:,k]][:,None]; c=n
 return c.sum(axis=0)
def matrices(x):
 h=L@x;hg=h[g];xx=hg[:,free];vv=xx[:,qi]*xx[:,qj];a=hg[:,0]
 M=[np.zeros((d,d),dtype=np.int64) for _ in range(4)]
 M[0][:dim,:dim]=xx.T@xx
 M[1][:dim,:dim]=xx.T@(a[:,None]*xx)
 M[1][:dim,dim:]=xx.T@vv
 M[2][:dim,dim:]=xx.T@(a[:,None]*vv)
 M[2][dim:,dim:]=vv.T@vv
 M[3][dim:,dim:]=vv.T@(a[:,None]*vv)
 return [m[ui,uj]*fac for m in M],coeff(h)[2:]*len(g)

if __name__=='__main__':
 T1=P.T@L
 T2=np.zeros((66,66))
 for k,(i,j) in enumerate(qpairs):
  for ell,(a,b) in enumerate(qpairs):
   T2[k,ell]=basis['qweight'][k]*(T1[i,a]*T1[j,b]+(T1[i,b]*T1[j,a] if a!=b else 0))
 T=la.block_diag(T1,T2)
 Qn=T.T@np.load(OUT/'Q.npy')@T
 Qn=(Qn+Qn.T)/2
 np.save(OUT/'Qnatural_float.npy',Qn)
 print('Q natural range/eigen',np.min(Qn),np.max(Qn),la.eigvalsh(Qn)[:3],flush=True)
 rng=np.random.default_rng(4405)
 samples=[]
 for j in range(dim):
  x=np.zeros(dim,dtype=np.int64);x[j]=1;samples.append(x)
 for k in range(120):
  x=np.zeros(dim,dtype=np.int64);inds=rng.choice(dim,min(2+k//30,5),replace=False)
  x[inds]=rng.choice([-1,1],size=len(inds));samples.append(x)
 allc=[[],[],[],[]];allb=[[],[],[],[]]
 for x in samples:
  cc,bb=matrices(x)
  for i in range(4): allc[i].append(cc[i]);allb[i].append(bb[i])
 C=[];b=[];selected=[]
 for i,rank in enumerate([2,3,11,18]):
  mat=np.array(allc[i]);rhs=np.array(allb[i]);row_scale=np.maximum(la.norm(mat.astype(float),axis=1),1)
  _,r,piv=la.qr((mat/row_scale[:,None]).T,pivoting=True,mode='economic')
  print('rank',i+2,np.abs(np.diag(r))[:rank+2],flush=True)
  ix=piv[:rank]
  C.extend(mat[ix]);b.extend(rhs[ix])
  selected.extend([dict(degree=i+2,x=samples[j].tolist()) for j in ix])
 C=np.array(C,dtype=np.int64);b=np.array(b,dtype=np.int64)
 scale=la.norm(C.astype(float),axis=1)
 _,r,piv=la.qr(C/scale[:,None],pivoting=True,mode='economic')
 cols=piv[:34]
 print('chosen cols',cols,'cond',np.linalg.cond(C[:,cols]/scale[:,None]),flush=True)
 sub=sp.Matrix(C[:,cols]);print('computing inverse',flush=True);s=time.time();inv=sub.inv();print('inverse time',time.time()-s,flush=True)
 D=10**6
 q0=np.rint(Qn[ui,uj]*D).astype(np.int64)
 residual=[int(D*b[i])-sum(int(C[i,j])*int(q0[j]) for j in range(len(ui))) for i in range(34)]
 corr=inv*sp.Matrix(residual)
 q=[sp.Rational(int(v),D) for v in q0]
 for j,v in zip(cols,corr):q[j]+=v/D
 den=sp.ilcm(*[v.q for v in q]);nums=[int(v*den) for v in q]
 Qexact=np.zeros((d,d));Qexact[ui,uj]=[float(v) for v in q];Qexact[uj,ui]=Qexact[ui,uj]
 print('common denominator digits',len(str(den)),'max correction',max(abs(float(v/D)) for v in corr), 'eig',la.eigvalsh(Qexact)[:5],flush=True)
 for deg in range(4):
  maxres=0
  for row,rhs in zip(allc[deg],allb[deg]):
   rr=sum(int(a)*v for a,v in zip(row,nums))-int(rhs)*int(den)
   maxres=max(maxres,abs(rr))
  print('EXACT sampled degree',deg+2,'maxres',maxres,flush=True)
  assert maxres==0
 data=dict(description='Rational Gram certificate for the zero-diagonal order-five doubly stochastic permanent',dimension=d,linear_dimension=dim,edges=edges,L=L.tolist(),free_edges=free,monomial_order='x_0,...,x_10, followed by x_i*x_j for 0<=i<=j<11 in lexicographic order',denominator=str(den),upper_numerators=[str(v) for v in nums],evaluation_points=selected,pivot_columns=cols.tolist(),rounding_denominator=D)
 (OUT/'certificate.json').write_text(json.dumps(data,separators=(',',':'))+'\n')
 np.savez(OUT/'exact_evaluation_matrix.npz',C=C,b=b,pivot_columns=cols)
 print('SAVED certificate.json',flush=True)
