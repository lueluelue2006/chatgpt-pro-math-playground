import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
os.environ['MKL_NUM_THREADS']='1'
import itertools as it
import json
import numpy as np
import scipy.linalg as la
import sympy as sp
import cvxpy as cp
from pathlib import Path

OUT=Path('sos_work'); OUT.mkdir(exist_ok=True)
edges=list(it.permutations(range(5),2)); ei={e:i for i,e in enumerate(edges)}
R=np.array([[int(i==r) for i,j in edges] for r in range(5)]+[[int(j==c) for i,j in edges] for c in range(5)],dtype=int)
L=np.array(sp.Matrix.hstack(*sp.Matrix(R).nullspace())).astype(int)
P=la.orth(L)
dim=P.shape[1]
qpairs=list(it.combinations_with_replacement(range(dim),2)); qi=np.array([i for i,j in qpairs]); qj=np.array([j for i,j in qpairs])
qweight=np.where(qi==qj,1,np.sqrt(2))
perms=list(it.permutations(range(5)))
dr=np.array([[ei[i,p[i]] for i in range(5)] for p in perms if all(i!=p[i] for i in range(5))])
g=[]
for p in perms:
 for transpose in [False,True]:
  g.append([ei[(p[j],p[i]) if transpose else (p[i],p[j])] for i,j in edges])
g=np.array(g)
d=dim+len(qpairs)
np.savez(OUT/'basis.npz',L=L,P=P,edges=edges,g=g,dr=dr,qi=qi,qj=qj,qweight=qweight)

def coeff(h):
 c=np.ones((44,1))
 for k in range(5):
  n=np.zeros((44,c.shape[1]+1)); n[:,:-1]+=c; n[:,1:]+=c*h[dr[:,k]][:,None]; c=n
 return c.sum(axis=0)

def setup(samples=60):
 rng=np.random.default_rng(4405)
 mats=[[],[],[],[]]; targets=[[],[],[],[]]
 for k in range(samples):
  x=rng.normal(size=dim); x=x/la.norm(x)*np.sqrt(dim)
  h=P@x
  hg=h[g]
  xg=hg@P
  vg=xg[:,qi]*xg[:,qj]*qweight
  a=hg[:,ei[0,1]]
  m2=np.zeros((d,d)); m3=m2.copy(); m4=m2.copy(); m5=m2.copy()
  m2[:dim,:dim]=xg.T@xg/len(g)
  m3[:dim,:dim]=xg.T@(a[:,None]*xg)/len(g)
  m3[:dim,dim:]=xg.T@vg/len(g);m3[dim:,:dim]=m3[:dim,dim:].T
  m4[dim:,dim:]=vg.T@vg/len(g)
  m4[:dim,dim:]=xg.T@(a[:,None]*vg)/len(g);m4[dim:,:dim]=m4[:dim,dim:].T
  m5[dim:,dim:]=vg.T@(a[:,None]*vg)/len(g)
  cc=coeff(h)
  for n,m in enumerate([m2,m3,m4,m5]):
   mats[n].append(m.reshape(-1)); targets[n].append(cc[n+2])
 constraints=[]; rhs=[]
 for n in range(4):
  m=np.array(mats[n]); b=np.array(targets[n]); u,s,vh=la.svd(m,full_matrices=False)
  rank=sum(s>s[0]*1e-10)
  residual=la.norm(u[:,rank:].T@b)
  print('degree',n+2,'rank',rank,'singular',s[:rank], 'targetres',residual,flush=True)
  constraints.append(vh[:rank]);rhs.append((u[:,:rank].T@b)/s[:rank])
 return np.vstack(constraints),np.concatenate(rhs)

if __name__=='__main__':
 A,b=setup()
 np.savez(OUT/'constraints.npz',A=A,b=b)
 Q=cp.Variable((d,d),symmetric=True)
 eps=cp.Variable()
 prob=cp.Problem(cp.Maximize(eps),[A@cp.vec(Q,order='C')==b,Q-eps*np.eye(d)>>0])
 print('Starting SDP',d,A.shape,flush=True)
 try:
  prob.solve(solver='CLARABEL',verbose=True,max_iter=150,tol_gap_abs=1e-9,tol_feas=1e-9,tol_gap_rel=1e-9)
 except Exception as e:
  print('Clarabel failed',e,flush=True)
 print('RESULT',prob.status,eps.value,flush=True)
 if Q.value is not None:
  np.save(OUT/'Q.npy',Q.value)
  print('eigs',la.eigvalsh(Q.value),flush=True)
  print('residual',la.norm(A@Q.value.reshape(-1)-b),flush=True)
