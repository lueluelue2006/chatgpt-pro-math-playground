#!/usr/bin/env python3
"""Audit the compact order-five zero-diagonal permanent certificate using exact Python integers.

Usage: python verify.py [--full] certificate.json

The default 34-test verification uses the standard library. The optional exhaustive
4368-test simplex-lattice check uses NumPy integer arrays. This verifier uses its own integral
test points, selected independently of the equations used to construct the Gram
matrix. It proves they determine all invariant identity coefficients.
"""
import argparse
import hashlib
import json
import random
from itertools import combinations, combinations_with_replacement, permutations
from math import comb
from pathlib import Path

N = 5
D = 11
EDGES = [(i,j) for i in range(N) for j in range(N) if i != j]
FREE = [(1,3),(1,4),(2,1),(2,3),(2,4),(3,1),(3,2),(3,4),(4,1),(4,2),(4,3)]
FI = [EDGES.index(e) for e in FREE]
P = list(permutations(range(N)))
E = EDGES.index((0,1))
DER = [[EDGES.index((i,j)) for i,j in enumerate(p)] for p in P if all(i != j for i,j in enumerate(p))]
G = [[EDGES.index((p[j],p[i]) if t else (p[i],p[j])) for i,j in EDGES] for p in P for t in (0,1)]

def embed(x):
    """Fill the remaining entries using row and column sums."""
    h = [[0]*N for i in range(N)]
    for (i,j),v in zip(FREE,x): h[i][j] = v
    for i in range(2,N): h[i][0] = -sum(h[i])
    h[1][0] = -sum(h[i][0] for i in range(2,N))
    h[1][2] = -sum(h[1])
    for j in range(N): h[0][j] = -sum(h[i][j] for i in range(1,N))
    assert all(sum(row)==0 for row in h) and all(sum(col)==0 for col in zip(*h))
    assert all(h[i][i]==0 for i in range(N))
    return [h[i][j] for i,j in EDGES]

def read_certificate(path):
    raw = Path(path).read_bytes()
    data = json.loads(raw)
    assert data['dimension']==26 and data['linear_dimension']==8 and data['margin']==[1,100]
    assert data['edges']==list(map(list,EDGES))
    features=data['features']; assert len(features)==26
    lin=[f[0] for f in features[:8] if len(f)==1]
    quad=[(i,j) for i,j in features[8:]]
    assert len(lin)==8 and len(quad)==18
    assert all(0<=j<len(EDGES) for f in features for j in f)
    B=len(features)
    coordinate_vectors = [embed([int(i==j) for j in range(D)]) for i in range(D)]
    L = list(map(list,zip(*coordinate_vectors)))
    assert data['L']==L
    den=int(data['denominator']); assert den>0
    nums=list(map(int,data['upper_numerators'])); assert len(nums)==B*(B+1)//2
    q=[[0]*B for _ in range(B)]
    for (i,j),v in zip(combinations_with_replacement(range(B),2),nums):
        q[i][j]=q[j][i]=v
    return L,den,q,lin,quad,hashlib.sha256(raw).hexdigest()

def positive_definite(den,q):
    """Bareiss symmetric elimination on the integer numerator of Q, without pivoting."""
    a=[row.copy() for row in q]
    B=len(a)
    previous=1
    for i in range(B):
        pivot=a[i][i]
        assert pivot>0,('Nonpositive leading minor',i+1)
        for j in range(i+1,B):
            u=a[i][j]
            for k in range(j,B):
                v,r=divmod(pivot*a[j][k]-u*a[i][k],previous)
                assert r==0
                a[j][k]=v
        previous=pivot
    return B

def invariant_dimensions(L):
    # Newton's identity gives the trace of Sym^k(g) from traces of g^j.
    totals=[0]*6
    for g in G:
        power=list(range(len(EDGES)))
        traces=[0]
        sym=[1]
        for k in range(1,6):
            power=[g[j] for j in power]
            traces.append(sum(L[power[f]][i] for i,f in enumerate(FI)))
            s,r=divmod(sum(traces[j]*sym[k-j] for j in range(1,k+1)),k)
            assert r==0
            sym.append(s)
        totals=[a+b for a,b in zip(totals,sym)]
    assert all(v%len(G)==0 for v in totals)
    return [v//len(G) for v in totals]

def det_mod(a,p):
    a=[[v%p for v in row] for row in a]
    n=len(a); result=1
    for i in range(n):
        j=next((j for j in range(i,n) if a[j][i]),None)
        if j is None:return 0
        if j!=i: a[i],a[j]=a[j],a[i];result=-result
        pivot=a[i][i];result=result*pivot%p;inv=pow(pivot,-1,p)
        for j in range(i+1,n):
            t=inv*a[j][i]%p
            for k in range(i+1,n):a[j][k]=(a[j][k]-t*a[i][k])%p
    return result%p

def unisolvent(ds):
    r=random.Random(1705)
    points=[embed([r.randrange(-2,3) for _ in range(D)]) for t in range(max(ds))]
    orbits=[[[h[j] for j in g] for g in G] for h in points]
    # The polynomials h -> sum_g <h,g h_j>^k are invariant since G permutes edges.
    dots=[[[sum(x*y for x,y in zip(h,gh)) for gh in orb] for orb in orbits] for h in points]
    witnesses=[]
    for k in range(2,6):
        d=ds[k]
        K=[[sum(w**k for w in dots[i][j]) for j in range(d)] for i in range(d)]
        assert all(K[i][j]==K[j][i] for i in range(d) for j in range(d))
        moddet=det_mod(K,1000003);assert moddet
        witnesses.append(moddet)
    return points,orbits,witnesses

def permanent_coeff(h,k):
    s=0
    for perm in DER:
        for inds in combinations(perm,k):
            v=1
            for idx in inds:v*=h[idx]
            s+=v
    return s

def audit_identity(q,den,ds,points,orbits,lin,quad):
    n=len(lin); m=len(quad)
    ll=[(i,j,q[i][j]*(1 if i==j else 2)) for i,j in combinations_with_replacement(range(n),2)]
    lq=[(i,j,2*q[i][n+j]) for i in range(n) for j in range(m)]
    qq=[(i,j,q[n+i][n+j]*(1 if i==j else 2)) for i,j in combinations_with_replacement(range(m),2)]
    count=0
    for t,(h,orb) in enumerate(zip(points,orbits)):
        sums=[0]*6
        for gh in orb:
            e=gh[E]
            x=[gh[i] for i in lin]
            y=[gh[i]*gh[j] for i,j in quad]
            a=sum(c*x[i]*x[j] for i,j,c in ll) if t<ds[3] else 0
            b=sum(c*x[i]*y[j] for i,j,c in lq) if t<ds[4] else 0
            c=sum(c*y[i]*y[j] for i,j,c in qq)
            sums[2]+=a
            sums[3]+=e*a+b
            sums[4]+=e*b+c
            sums[5]+=e*c
        for k in range(2,6):
            if t<ds[k]:
                norm2=sum(v*v for v in h) if k==2 else 0
                assert 100*sums[k] == len(G)*den*(100*permanent_coeff(h,k)-norm2),('Identity fails',t,k)
                count+=1
    return count

def simplex(d,total):
    if d==1:
        yield (total,)
    else:
        for i in range(total+1):
            for tail in simplex(d-1,total-i):
                yield (i,)+tail

def audit_lattice(q,den,lin,quad):
    import numpy as np
    upper=list(combinations_with_replacement(range(len(q)),2))
    a,b=np.array(upper).T
    weights=np.array([q[i][j]*(1 if i==j else 2) for i,j in upper],dtype=object)
    group=np.array(G); der=np.array(DER); qi,qj=np.array(quad).T
    n=0
    for degree in range(6):
        for coord in simplex(D,degree):
            h=np.array(embed(coord),dtype=np.int32)
            assert max(abs(h))<=5
            gh=h[group]
            z=np.column_stack((gh[:,lin],gh[:,qi]*gh[:,qj]))
            w=1+gh[:,E]
            # |w| <= 6, |z| <= 25. All integer sums fit signed 32 bits.
            gram=z.T@(w[:,None]*z)
            assert abs(gram).max()<=240*6*25**2
            rhs=weights@gram[a,b].astype(object)
            norm2=int(h@h)
            lhs=int((1+h[der]).prod(axis=1).sum())-44
            assert 100*rhs == len(G)*den*(100*lhs-norm2),('Lattice identity fails',coord)
            n+=1
    assert n==comb(D+5,5)
    return n

def main():
    arg=argparse.ArgumentParser(description=__doc__)
    arg.add_argument('certificate')
    arg.add_argument('--full',action='store_true')
    args=arg.parse_args()
    L,den,q,lin,quad,digest=read_certificate(args.certificate)
    assert len(set(tuple(g) for g in G))==240
    assert len(DER)==44
    # Both sides have constant and linear part zero. The permanent's linear
    # coefficient is an invariant homogeneous linear form, and ds[1] is zero.
    ds=invariant_dimensions(L)
    assert ds==[1,0,2,3,11,18]
    points,orbits,witnesses=unisolvent(ds)
    count=audit_identity(q,den,ds,points,orbits,lin,quad)
    pivots=positive_definite(den,q)
    print('SHA256',digest)
    print('Invariant dimensions, degrees zero through five:',*ds)
    print('Orbit-kernel determinants modulo 1000003:',*witnesses)
    print('Verified independent polynomial identity checks:',count)
    print('Positive leading principal minors of the Gram numerator:',pivots)
    if args.full:
        print('Verified all simplex-lattice identity checks:',audit_lattice(q,den,lin,quad))
    print('Exact certificate verified.')

if __name__=='__main__':
    if not __debug__: raise SystemExit('Run with assertions enabled.')
    main()
