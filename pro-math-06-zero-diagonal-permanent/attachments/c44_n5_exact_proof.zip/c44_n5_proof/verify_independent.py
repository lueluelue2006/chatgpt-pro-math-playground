#!/usr/bin/env python3
"""Check the order-five zero-diagonal permanent certificate with exact integers.

Usage: python verify_independent.py certificate.json
"""
from itertools import combinations, combinations_with_replacement, permutations
from math import prod
from pathlib import Path
import argparse
import hashlib
import json
import random


N = 5
EDGES = [(i, j) for i in range(N) for j in range(N) if i != j]
FREE = [(1, 3), (1, 4), (2, 1), (2, 3), (2, 4), (3, 1),
        (3, 2), (3, 4), (4, 1), (4, 2), (4, 3)]
PERMS = list(permutations(range(N)))
G = [[EDGES.index((p[j], p[i]) if transpose else (p[i], p[j]))
      for i, j in EDGES] for p in PERMS for transpose in (0, 1)]
DER = [[EDGES.index((i, j)) for i, j in enumerate(p)]
       for p in PERMS if all(i != j for i, j in enumerate(p))]


def embed(coordinates):
    h = [[0] * N for i in range(N)]
    for (i, j), v in zip(FREE, coordinates):
        h[i][j] = v
    for i in range(2, N):
        h[i][0] = -sum(h[i])
    h[1][0] = -sum(h[i][0] for i in range(2, N))
    h[1][2] = -sum(h[1])
    for j in range(N):
        h[0][j] = -sum(h[i][j] for i in range(1, N))
    assert all(sum(row) == 0 for row in h)
    assert all(sum(col) == 0 for col in zip(*h))
    assert all(h[i][i] == 0 for i in range(N))
    return [h[i][j] for i, j in EDGES]


def read_certificate(path):
    raw = Path(path).read_bytes()
    data = json.loads(raw)
    n = data['dimension']
    dl = data['linear_dimension']
    denom = int(data['denominator'])
    features = data['features']
    assert n == 26 and dl == 8 and denom > 0 and data['margin'] == [1, 100]
    assert data['edges'] == [list(e) for e in EDGES]
    assert [len(f) for f in features] == [1]*dl + [2]*(n-dl)
    assert all(0 <= j < len(EDGES) for f in features for j in f)
    nums = [int(v) for v in data['upper_numerators']]
    assert len(nums) == n*(n+1)//2
    matrix = [[0] * n for i in range(n)]
    for (i, j), v in zip(combinations_with_replacement(range(n), 2), nums):
        matrix[i][j] = matrix[j][i] = v
    return denom, features, matrix, hashlib.sha256(raw).hexdigest()


def positive_definite(matrix):
    a = [row[:] for row in matrix]
    previous = 1
    for i in range(len(a)):
        pivot = a[i][i]
        assert pivot > 0, ('nonpositive leading minor', i+1)
        for j in range(i+1, len(a)):
            for k in range(j, len(a)):
                v, r = divmod(pivot*a[j][k] - a[i][j]*a[i][k], previous)
                assert r == 0
                a[j][k] = v
        previous = pivot


def invariant_dimensions():
    sums = [0]*6
    for p in PERMS:
        for transpose in (0, 1):
            q = list(range(N))
            traces = [0]
            sym = [1]
            for k in range(1, 6):
                q = [p[j] for j in q]
                fixed = sum(i == j for i, j in enumerate(q))
                swapped = sum(i != j and q[j] == i for i, j in enumerate(q))
                traces.append(swapped-1 if transpose*k % 2 else fixed*fixed-3*fixed+1)
                h, r = divmod(sum(traces[j]*sym[k-j] for j in range(1, k+1)), k)
                assert r == 0
                sym.append(h)
            sums = [x+y for x, y in zip(sums, sym)]
    assert all(v % len(G) == 0 for v in sums)
    return [v//len(G) for v in sums]


def determinant_mod(matrix, prime):
    a = [[v % prime for v in row] for row in matrix]
    n = len(a)
    determinant = 1
    for i in range(n):
        j = next((j for j in range(i, n) if a[j][i]), None)
        if j is None:
            return 0
        if i != j:
            a[i], a[j] = a[j], a[i]
            determinant = -determinant
        pivot = a[i][i]
        determinant = determinant*pivot % prime
        inv = pow(pivot, -1, prime)
        for j in range(i+1, n):
            scale = inv*a[j][i] % prime
            for k in range(i+1, n):
                a[j][k] = (a[j][k] - scale*a[i][k]) % prime
    return determinant % prime


def independent_evaluations(ds):
    rng = random.Random(1705)
    points = [embed([rng.randrange(-2, 3) for j in FREE]) for i in range(max(ds))]
    orbits = [[[h[j] for j in g] for g in G] for h in points]
    dots = [[[sum(x*y for x, y in zip(h, gh)) for gh in orb] for orb in orbits] for h in points]
    witnesses = []
    for k in range(2, 6):
        d = ds[k]
        kernel = [[sum(t**k for t in dots[i][j]) for j in range(d)] for i in range(d)]
        det = determinant_mod(kernel, 1000003)
        assert det
        witnesses.append(det)
    return points, orbits, witnesses


def verify_identity(denom, features, matrix, ds, points, orbits):
    pairs = list(combinations_with_replacement(range(len(features)), 2))
    terms = {k: [] for k in range(2, 5)}
    for i, j in pairs:
        degree = len(features[i]) + len(features[j])
        terms[degree].append((i, j, matrix[i][j]*(1 if i == j else 2)))
    count = 0
    for index, (h, orbit) in enumerate(zip(points, orbits)):
        sums = [0]*6
        for gh in orbit:
            z = [prod(gh[j] for j in f) for f in features]
            weight = gh[EDGES.index((0, 1))]
            for k in range(2, 5):
                total = sum(c*z[i]*z[j] for i, j, c in terms[k])
                sums[k] += total
                sums[k+1] += weight*total
        for k in range(2, 6):
            if index >= ds[k]:
                continue
            permanent = sum(prod(h[i] for i in s) for p in DER for s in combinations(p, k))
            target = 100*permanent - (sum(x*x for x in h) if k == 2 else 0)
            assert 100*sums[k] == len(G)*denom*target, ('identity failed', index, k)
            count += 1
    return count


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('certificate')
    args = parser.parse_args()
    assert len(G) == len({tuple(g) for g in G}) == 240 and len(DER) == 44
    denom, features, matrix, digest = read_certificate(args.certificate)
    positive_definite(matrix)
    ds = invariant_dimensions()
    assert ds == [1, 0, 2, 3, 11, 18]
    points, orbits, dets = independent_evaluations(ds)
    checked = verify_identity(denom, features, matrix, ds, points, orbits)
    print('SHA256', digest)
    print('Invariant dimensions:', *ds)
    print('Determinants modulo 1000003:', *dets)
    print('Independent evaluations checked:', checked)
    print('Strictly positive leading minors:', len(matrix))
    print('Exact certificate verified.')


if __name__ == '__main__':
    if not __debug__:
        raise SystemExit('Run with assertions enabled.')
    main()
