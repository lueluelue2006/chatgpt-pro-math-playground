恰有四个 1 的二元串：完整证明与可复跑检验

结论：对于每个 n>=8，最少不同阿贝尔平方因子数为 floor((n+2)/4)。

文件：
  proof_zh.txt          中文完整证明、文献出处、枚举公式。
  check_four.py         仅用 Python 标准库的精确枚举程序。
  results_8_64.json     本次四工作进程运行的完整结果。

重现命令（在解压后的文件夹中运行）：
  python3 check_four.py --max-n 64 --direct-limit 20 --workers 4 --output results.json

小规模快速运行：
  python3 check_four.py --max-n 24 --direct-limit 20 --workers 4

程序枚举所有五个非负零间隔，不做反转折半。
--direct-limit 控制直接扫描子串并按字面去重的交叉核验上限。
较长串采用证明文档中列明的精确集合计数公式。

本次检查：n=8..64，总计 8,259,832 个串；其中 n=8..20 的 20,293 个
串逐一通过两种独立计数实现的交叉核验。
运行使用四个工作进程。不同计算机的耗时可能不同。
实验不代替数学证明；proof_zh.txt 给出的证明覆盖全部 n>=8。
