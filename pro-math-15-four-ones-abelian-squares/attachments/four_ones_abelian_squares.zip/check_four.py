#!/usr/bin/env python3
"""Reproducible check: distinct abelian squares in words with exactly four 1s.

The proved minimum for n >= 8 is floor((n+2)/4).
This program is an independent finite check, not a substitute for the proof.
It uses two counting methods: direct factor sets for short words, and an exact
five-gap formula (with inclusion-exclusion to remove duplicate two-1 factors).

Usage (Python 3, standard library only):
    python3 check_four.py --max-n 64 --direct-limit 20 --workers 4 --output results.json

Original problem and two-1 lower bound:
    https://arxiv.org/html/2604.23188v1#S6
    https://arxiv.org/html/2604.23188v1#S3
"""
from itertools import combinations
from collections import defaultdict
import argparse
import json
import math
import platform
import time
from functools import partial
from multiprocessing import Pool


def rectangle(g, left, right):
    """Number of pairs 0<=x<=left, 0<=y<=right with |x-y|<=g
    and x-y congruent to g modulo 2 (all inputs nonnegative)."""
    le, lo = left // 2 + 1, (left + 1) // 2
    re, ro = right // 2 + 1, (right + 1) // 2
    total = le * re + lo * ro if g % 2 == 0 else le * ro + lo * re

    def tail(t, cap):
        if t <= 1:
            return 0
        last = min(cap, t - 2)
        return t * t // 4 - (t - last - 1) ** 2 // 4

    return total - tail(left - g, right) - tail(right - g, left)


def gap_count(gaps):
    a, b, c, d, e = gaps
    s0 = max(gaps) // 2
    groups = defaultdict(list)
    for left, g, right in [(a, b, c), (b, c, d), (c, d, e)]:
        groups[g].append((left, right))
    s2 = 0
    for g, rects in groups.items():
        for k in range(1, len(rects) + 1):
            for subset in combinations(rects, k):
                s2 += (-1) ** (k + 1) * rectangle(
                    g, min(p[0] for p in subset), min(p[1] for p in subset)
                )
    # Write u=x+b and v=y+d; cut a shifted rectangle from a prefix rectangle.
    s4 = rectangle(c, a + b, d + e)
    if b:
        s4 -= rectangle(c, b - 1, d + e)
    if d:
        s4 -= rectangle(c, a + b, d - 1)
    if b and d:
        s4 += rectangle(c, b - 1, d - 1)
    return s0, s2, s4


def direct(gaps):
    w = '1'.join('0' * x for x in gaps)
    prefix = [0]
    for ch in w:
        prefix.append(prefix[-1] + (ch == '1'))
    factors = set()
    for h in range(1, len(w) // 2 + 1):
        for i in range(len(w) - 2 * h + 1):
            if prefix[i + h] - prefix[i] == prefix[i + 2 * h] - prefix[i + h]:
                factors.add(w[i:i + 2 * h])
    return tuple(sum(s.count('1') == k for s in factors) for k in (0, 2, 4))


def gaps_with_sum(z):
    for a in range(z + 1):
        for b in range(z - a + 1):
            for c in range(z - a - b + 1):
                for d in range(z - a - b - c + 1):
                    yield a, b, c, d, z - a - b - c - d


def check_n(n, direct_limit=20):
    best = n
    examples = []
    count = 0
    short02 = []
    for g in gaps_with_sum(n - 4):
        parts = gap_count(g)
        if n <= direct_limit:
            assert parts == direct(g), (g, parts, direct(g))
        total = sum(parts)
        # A stronger intermediate lemma used in the human proof.
        assert total >= (sum(g[:3]) // 2) + 1, (g, parts)
        if total < best:
            best, examples = total, [g]
        elif total == best and len(examples) < 6:
            examples.append(g)
        if sum(parts[:2]) < (n + 2) // 4:
            short02.append(g)
        count += 1
    assert best == (n + 2) // 4, (n, best, examples)
    assert count == math.comb(n, 4)
    z = n - 4
    q = 2 * ((z + 2) // 4) + 1
    p = z - q
    construction = (0, q, 0, 0, p)
    assert p >= 0 and q > p and q % 2 == 1
    assert gap_count(construction) == (q // 2, 1, 0)
    assert sum(gap_count(construction)) == best
    return dict(n=n, minimum=best, words_checked=count, witnesses=examples,
                construction=construction, short_zero_two=short02)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--min-n', type=int, default=8)
    ap.add_argument('--max-n', type=int, default=40)
    ap.add_argument('--direct-limit', type=int, default=20)
    ap.add_argument('--workers', type=int, default=4)
    ap.add_argument('--output')
    args = ap.parse_args()
    assert 1 <= args.workers <= 4
    assert 8 <= args.min_n <= args.max_n
    ns = range(args.min_n, args.max_n + 1)
    started = time.perf_counter()
    with Pool(args.workers) as pool:
        rows = list(pool.imap(partial(check_n, direct_limit=args.direct_limit), ns))
    elapsed = time.perf_counter() - started
    for row in rows:
        print(row['n'], row['minimum'], row['words_checked'], row['witnesses'][0],
              'short02=', len(row['short_zero_two']))
    total = sum(row['words_checked'] for row in rows)
    direct_total = sum(row['words_checked'] for row in rows if row['n'] <= args.direct_limit)
    print('TOTAL', total, 'DIRECT_CROSS_CHECKED', direct_total,
          'WORKERS', args.workers, 'SECONDS', round(elapsed, 3))
    if args.output:
        with open(args.output, 'w') as out:
            json.dump(dict(python=platform.python_version(), workers=args.workers,
                           max_n=args.max_n, min_n=args.min_n,
                           direct_limit=args.direct_limit, elapsed_seconds=elapsed,
                           total_checked=total, direct_cross_checked=direct_total,
                           rows=rows), out, indent=2)


if __name__ == '__main__':
    main()
