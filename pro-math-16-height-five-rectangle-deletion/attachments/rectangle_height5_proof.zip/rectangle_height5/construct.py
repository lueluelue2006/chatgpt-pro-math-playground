"""Explicit optimal deletions for the grid {0,...,5} x {0,...,m}.

python3 construct.py 20 > edges_m20.json
python3 construct.py --self-test

Coordinates in the JSON are (row, column), exactly as in the problem.
All bit masks in this file describe DELETED edges.
"""
import argparse
import json
from itertools import combinations

PAIRS = list(combinations(range(6), 2))
NORMAL = [(10, 9), (4, 20), (18, 1)]
TAIL = [(4, 18), (16, 5), (10, 16)]


def reflect(mask, bits):
    return sum(((mask >> i) & 1) << (bits - 1 - i) for i in range(bits))


def reflect_action(action):
    h, v = action
    return reflect(h, 6), reflect(v, 5)


def vertical_pairs(cut):
    return {p for p in PAIRS
            if not (cut & ((1 << p[1]) - (1 << p[0])))}


def horizontal_pairs(cut):
    return {p for p in PAIRS
            if not (cut & ((1 << p[0]) | (1 << p[1])))}


def move(state, action):
    h, v = action
    live = state & horizontal_pairs(h)
    new = vertical_pairs(v)
    if live & new:
        raise RuntimeError(("An intact rectangle closes", live & new))
    return live | new, live


def construction(m):
    if m < 2:
        raise ValueError("This construction is stated for m >= 2")
    prefix = m - 3 if m % 3 == 1 else m
    actions = []
    for j in range(prefix):
        action = NORMAL[j % 3]
        actions.append(reflect_action(action) if (j // 3) % 2 else action)
    if m % 3 == 1:
        mirrored = ((prefix - 1) // 3) % 2
        actions.extend(reflect_action(a) if mirrored else a for a in TAIL)
    return [16] + [v for h, v in actions], [0] + [h for h, v in actions]


def verify_frontier(vertical, horizontal):
    state = vertical_pairs(vertical[0])
    for h, v in zip(horizontal[1:], vertical[1:]):
        state, _ = move(state, (h, v))


def verify_all_rectangles(vertical, horizontal):
    """Direct perimeter check, independent of frontier state updates."""
    m = len(vertical) - 1
    prefix = [[0] * (m + 1) for _ in range(6)]
    for row in range(6):
        for j in range(1, m + 1):
            prefix[row][j] = prefix[row][j-1] + ((horizontal[j] >> row) & 1)
    for a, b in PAIRS:
        needed = (1 << b) - (1 << a)
        for left in range(m):
            if vertical[left] & needed:
                continue
            for right in range(left + 1, m + 1):
                if vertical[right] & needed:
                    continue
                if (prefix[a][right] == prefix[a][left] and
                        prefix[b][right] == prefix[b][left]):
                    raise RuntimeError(("Intact rectangle", a, b, left, right))


def verify_transition_certificate():
    def clique(rows):
        return set(combinations(rows, 2))

    def reflected_state(state):
        return {(5-b, 5-a) for a, b in state}

    T = clique(range(5)) | {(3, 5)}
    if not vertical_pairs(16) <= T:
        raise RuntimeError("Initial envelope is incorrect")
    state = T
    expected = [{(0, 2), (0, 4), (2, 4)},
                {(0, 4), (1, 3), (4, 5)}, {(0, 2)}]
    first_state = None
    for i, action in enumerate(NORMAL):
        state, live = move(state, action)
        if live != expected[i]:
            raise RuntimeError("Ordinary live-pair table is incorrect")
        if i == 0:
            first_state = state
    if state != reflected_state(T):
        raise RuntimeError("Three steps do not reflect the envelope")
    for action in map(reflect_action, NORMAL):
        state, _ = move(state, action)
    if state != T:
        raise RuntimeError("Six-step period failed")
    state = first_state
    expected = [{(0, 4), (1, 3), (4, 5)},
                {(0, 1), (1, 3), (2, 3)}, {(4, 5)}]
    for i, action in enumerate(TAIL):
        state, live = move(state, action)
        if live != expected[i]:
            raise RuntimeError("Tail live-pair table is incorrect")
    state = reflected_state(first_state)
    for action in map(reflect_action, TAIL):
        state, _ = move(state, action)


def self_test():
    verify_transition_certificate()
    for m in range(2, 21):
        vertical, horizontal = construction(m)
        cost = sum(x.bit_count() for x in vertical + horizontal)
        if cost != (10*m + 4) // 3:
            raise RuntimeError(("Wrong edge count", m, cost))
        verify_frontier(vertical, horizontal)
        verify_all_rectangles(vertical, horizontal)
    print("Verified the six-step cycle and both three-step tails.")
    print("Verified exact edge counts and every rectangle for m=2..20.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("m", nargs="?", type=int)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
    if args.m is None:
        if not args.self_test:
            parser.error("Provide m or --self-test")
        return
    vertical, horizontal = construction(args.m)
    verify_frontier(vertical, horizontal)
    edges = []
    for j, cut in enumerate(vertical):
        for row in range(5):
            if cut & (1 << row):
                edges.append([[row, j], [row + 1, j]])
    for j in range(1, args.m + 1):
        for row in range(6):
            if horizontal[j] & (1 << row):
                edges.append([[row, j-1], [row, j]])
    print(json.dumps({"m": args.m, "minimum_deletions": len(edges),
                      "formula": (10*args.m + 4) // 3,
                      "coordinate_order": ["row", "column"],
                      "deleted_unit_edges": edges}, indent=2))


if __name__ == "__main__":
    main()
