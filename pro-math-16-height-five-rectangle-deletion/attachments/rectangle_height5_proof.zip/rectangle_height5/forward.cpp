// Independent forward DP: masks in this file represent KEPT edges.
// Compile: g++ -O2 -std=c++17 forward.cpp -o forward
// Run: ./forward
#include <algorithm>
#include <array>
#include <iostream>
#include <vector>

constexpr int N = 1 << 15;
constexpr int INF = 1000000; // Finite costs here are at most 11*14+5 = 159.
using Vector = std::vector<int>;
std::array<int, 64> horizontal_pairs{}, horizontal_cost{};
std::array<int, 32> vertical_pairs{}, vertical_cost{};

int popcount(int x) {
    int result = 0;
    while (x) { result += x & 1; x >>= 1; }
    return result;
}

Vector advance(const Vector& f) {
    Vector g(N, INF), result(N, INF);
    for (int s = 0; s < N; ++s) if (f[s] != INF) {
        for (int h = 0; h < 64; ++h) {
            int q = s & horizontal_pairs[h];
            g[q] = std::min(g[q], f[s] + horizontal_cost[h]);
        }
    }
    for (int q = 0; q < N; ++q) if (g[q] != INF) {
        for (int v = 0; v < 32; ++v) if (!(q & vertical_pairs[v])) {
            int s = q | vertical_pairs[v];
            result[s] = std::min(result[s], g[q] + vertical_cost[v]);
        }
    }
    return result;
}

int main() {
    for (int h = 0; h < 64; ++h) {
        horizontal_cost[h] = 6 - popcount(h);
        int k = 0;
        for (int a = 0; a < 6; ++a)
            for (int b = a + 1; b < 6; ++b, ++k)
                if ((h & (1 << a)) && (h & (1 << b)))
                    horizontal_pairs[h] |= 1 << k;
    }
    for (int v = 0; v < 32; ++v) {
        vertical_cost[v] = 5 - popcount(v);
        int k = 0;
        for (int a = 0; a < 6; ++a)
            for (int b = a + 1; b < 6; ++b, ++k) {
                int needed = (1 << b) - (1 << a);
                if ((v & needed) == needed) vertical_pairs[v] |= 1 << k;
            }
    }
    Vector f(N, INF), base;
    for (int v = 0; v < 32; ++v)
        f[vertical_pairs[v]] = std::min(f[vertical_pairs[v]], vertical_cost[v]);
    const int expected[] = {0,5,8,11,14,18,21,24,28,31,34,38,41,44,48};
    for (int m = 0; m <= 14; ++m) {
        int best = *std::min_element(f.begin(), f.end());
        if (best != expected[m]) return 1;
        std::cout << m << " " << best << "\n";
        if (m == 11) base = f;
        if (m < 14) f = advance(f);
    }
    int finite = 0;
    for (int s = 0; s < N; ++s) {
        int expected_value = base[s] == INF ? INF : base[s] + 10;
        if (f[s] != expected_value) return 2;
        if (f[s] != INF) ++finite;
    }
    std::cout << "D_14(S) = D_11(S) + 10: all " << N << " states; "
              << finite << " finite states\n";
}
