"""Exact backward DP certificate. Python >= 3.10; standard library only.

Q is the set of live row pairs just before processing the current column.
F_t[Q] counts the current vertical column and t further unit-width strips.
Every action below is generated from a mask of DELETED unit edges.
"""
from itertools import combinations

pairs = list(combinations(range(6), 2))
states = range(1 << len(pairs))


def actions(required, slots):
    return [(sum(1 << i for i, need in enumerate(required) if not (cut & need)),
             cut.bit_count()) for cut in range(1 << slots)]


V = actions([(1 << b) - (1 << a) for a, b in pairs], 5)
H = actions([(1 << a) | (1 << b) for a, b in pairs], 6)
F = [min(c for v, c in V if not (q & v)) for q in states]
opt = [F[0]]
for m in range(1, 14):
    G = [min(c + F[s & h] for h, c in H) for s in states]
    F = [min(c + G[q | v] for v, c in V if not (q & v)) for q in states]
    opt.append(F[0])
    if m == 10:
        base = F

expected = [0, 5, 8, 11, 14, 18, 21, 24, 28, 31, 34, 38, 41, 44]
if opt != expected:
    raise RuntimeError(("Unexpected minimum values", opt))
checked = sum(F[q] == base[q] + 10 for q in states)
if checked != len(states):
    raise RuntimeError(("Full-vector period failed", checked))
print("S(5,m), m=0..13:", opt)
print("F_13(Q) = F_10(Q) + 10:", checked, "of", len(states), "states")
