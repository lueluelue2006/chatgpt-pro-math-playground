四次和集大小：证明与可复跑证书
2026-11-18

定理
对每个整数 k >= 5，k 元整数集合 A 的 |4A| 恰好遍历
[4k-3, C(k+3,4)] 去掉 {4k-2, 4k-1, 4k+2}。
加数允许重复。

证明结构
1. Lev 的增长不等式排除三个禁值，普通和集界给出上下界。
2. PDF 中的解析构造证明所有 k >= 37；这一部分不使用计算机枚举。
3. independent_finite_certificate.py 完整验证 5 <= k <= 36 的
   655360 个允许 (k,N) 对。每个标记都来自明确的整数集合构造。

文件
fourfold_sumset_proof.pdf            完整中文证明，附有限校验脚本全文
fourfold_sumset_proof.html           同一证明的独立 HTML / MathML 版本
independent_finite_certificate.py    小范围完整证书与单个见证生成
fourfold_construct.py               任意 k >= 5 的整数见证生成器
verification.txt                   本次实际运行的结果
SHA256SUMS.txt                     文件完整性校验值

运行环境
Python 3.10 或更高版本；仅使用标准库，无第三方包、网络或数据文件。
本次主验证使用 Python 3.12.14，单进程。
请把两个 .py 文件放在同一目录。

复跑完整有限证明
    python independent_finite_certificate.py

生成一个小范围见证，并直接数出四次和集
    python independent_finite_certificate.py 5 61
    python independent_finite_certificate.py 36 406

运行通用构造器的边界自测
    python fourfold_construct.py

为任意允许的 (k,N) 生成整数见证
    python fourfold_construct.py 37 696

同时直接计数最终集合的全部四次和
    python fourfold_construct.py 37 696 --verify

--verify 枚举 C(k+3,4) 个四元可重复组合，大 k 时可耗用较多内存。
未指定 --verify 时，程序明确标注结果来自构造公式或有限证书。
所有中间计算都使用精确整数。见证坐标可能很大，这是构造允许的。

实例
k=5, N=61: A={0,1,14,19,22}。
k=36, N=406: A=[0,33] 并 {45,165}。
k=37, N=696: A=[0,33] 并 {35,141,449}。

文献依赖
Isaac Rajagopal, Possible Sizes of Sumsets,
Discrete Analysis 2026:2, DOI 10.19086/da.165102,
https://arxiv.org/html/2510.23022v3
原文猜想 1.6 的 h=4 情形就是本题。本文可达性证明为本次推导。

Vsevolod F. Lev, Structure theorem for multiple addition and the Frobenius
problem, Journal of Number Theory 58(1) (1996), 79-88,
DOI 10.1006/jnth.1996.0065。
其增长不等式在 Rajagopal 定理 2.2 中列出，用于排除三个禁值。

数学证明与实现验证的区别
有限覆盖由精确生成函数公式、穷举明确有限构造族和完整位集合断言组成。
随机样例和边界样例的直接计数用于交叉核验代码，不替代覆盖证明。
无限范围由解析证明给出，不由有限实验外推。
