"""Construct a k-element set of integers A with |4A| = N, for every k >= 5.

Use Python 3.10 or later. Run without arguments for boundary tests. Run
    python fourfold_construct.py 37 696 --verify
for a witness and a direct count of its four-term sums. With no --verify,
the reported size is certified by the construction. Direct verification uses
C(k+3,4) quadruples and may require substantial memory at large k.

For k <= 36, keep independent_finite_certificate.py beside this file.
For k >= 37, this file contains the entire construction. All sets are
specified by actual nonnegative integers, including the high-range models.
"""
import argparse
import sys
from itertools import combinations_with_replacement
from math import comb, isqrt


def allowed(k, N):
    return (k >= 5 and 4*k-3 <= N <= comb(k+3, 4)
            and N not in (4*k-2, 4*k-1, 4*k+2))


def low_range(k, N):
    """Use the filling set B and the identity 4A = {0} union [u,4u+4d]."""
    u = next(i for i in range(1, 5) if (N-3*i-2) % 4 == 0)
    d = (N-3*u-2)//4
    if not k-2 <= d <= 10*k-74:
        raise AssertionError('Filling-set diameter outside its proven range')
    # Include both four-element ends and put points at most ten apart.
    B = set(range(4)) | set(range(d-3, d+1)) | set(range(13, d-3, 10))
    for x in range(d+1):
        if len(B) == k-1:
            break
        B.add(x)
    if len(B) != k-1 or 4*d+3*u+2 != N:
        raise AssertionError('Incorrect filling-set parameters')
    return [0] + [u+x for x in sorted(B)]


def ap_endpoint(k, c):
    """Fourth size of an arithmetic progression of length k-c plus c free points."""
    return comb(c+5, 4) + (k-c-2)*comb(c+4, 3)


def free_value(n, c, t):
    """Fourth size of the core [0,n] union {t} with c free points."""
    h = [1]
    for j in range(1, 5):
        h.append(h[-1] + min(t, j*n+1))
    return h[4] + c*h[3] + comb(c+1, 2)*h[2] + comb(c+2, 3)*h[1] + comb(c+3, 4)


def first_true(lo, hi, test):
    """First true point of a monotone predicate on an interval ending in true."""
    while lo < hi:
        mid = (lo+hi)//2
        if test(mid):
            hi = mid
        else:
            lo = mid+1
    return lo


def adjustments(k, c, n, delta):
    """Decompose delta into k*m + v + C(q,2) + e under the point budget."""
    if not 0 <= delta < comb(c+3, 2):
        raise AssertionError('Deficit exceeds the one-step bound')
    if c <= 10:
        # For c <= 6 the whole range uses no mixed-radix chain. For 7..10
        # one ternary carry supplies the second interval starting at k.
        m = int(c >= 7 and delta >= k)
        rest = delta-m*k
        q_limit = c-2 if m == 0 else c-4
        v = 0
    else:
        m, rest = divmod(delta, k)
        L = c-3-m
        # Starting at q=0, intervals [C(q,2), C(q,2)+n+L-q] overlap
        # through this index. The proof bounds their last right endpoint.
        q_limit = min(L, (L+n+1)//2+1)
    q = min(q_limit, (1+isqrt(1+8*rest))//2) if rest else 0
    remainder = rest-comb(q, 2)
    e = min(remainder, n)
    if c >= 11:
        v = remainder-e
    used = 2+q+(1+m+v if m+v else 0)
    if (min(m, v, q, e) < 0 or used > c or e > n
            or m*k+v+comb(q, 2)+e != delta):
        raise AssertionError('Invalid deficit decomposition')
    return m, v, q, e


def regulator_shift(n, t, e):
    """Give a shift with |B intersection (s+3B)| = e for B = [0,n] union {t}."""
    if e == 0:
        return t+1
    for s in (n+1-e, n+2-e):
        if 1 <= s <= n+1 and n+1-s+int(s >= t-3*n) == e:
            return s
    raise AssertionError('The one-point overlap profile missed a shift')


def high_range(k, N):
    # The c-th core interval runs from ap_endpoint(k,c) to ap_endpoint(k,c+1).
    c = first_true(2, k-3, lambda j: ap_endpoint(k, j+1) >= N)
    n = k-c-2
    t = first_true(n+1, 4*n+1, lambda x: free_value(n, c, x) >= N)
    delta = free_value(n, c, t)-N
    m, v, q, e = adjustments(k, c, n, delta)
    s = regulator_shift(n, t, e)
    M = 4*max(t, s)+1
    A = list(range(n+1)) + [t, M, 3*M+s]

    # In a common-zero direct sum, multiply all positive elements of the
    # next block by 4*max(A)+1. Four old-coordinate summands stay below it.
    if m+v:
        stride = 4*A[-1]+1
        value = stride  # the first nonzero point of the mixed-radix block
        A.append(value)
        for radix, count in ((3, m), (4, v)):
            for _ in range(count):
                value *= radix
                A.append(value)
    if q:
        stride = 4*A[-1]+1
        power = 1
        for _ in range(q):
            power *= 3
            A.append(stride*(power-1))  # {1,3,...,3^q} translated by -1
    for _ in range(k-len(A)):
        A.append(4*A[-1]+1)
    return A


def witness(k, N):
    """Return the requested, strictly increasing k-tuple as a list of integers."""
    if not allowed(k, N):
        raise ValueError('The pair is outside the fourfold spectrum for k >= 5.')
    if k <= 36:
        from independent_finite_certificate import witness as finite_witness
        A = finite_witness(k, N)
    elif N <= 20*k-45:
        A = low_range(k, N)
    else:
        A = high_range(k, N)
    if len(A) != k or any(x >= y for x, y in zip(A, A[1:])):
        raise AssertionError('The output must contain k distinct ordered integers')
    return A


def direct_size(A):
    return len({sum(values) for values in combinations_with_replacement(A, 4)})


def self_test():
    k = 37
    cases = [(5, 17), (36, comb(39, 4)), (k, 4*k-3), (k, 4*k),
             (k, 4*k+1), (k, 4*k+3), (k, 4*k+6), (k, 20*k-45),
             (k, comb(k+3, 4))]
    for c in (2, 6, 7, 10, 11, 14, 15, 23, 24, 33, 34):
        # One step above this left endpoint uses the maximal deficit J-1.
        cases.append((k, ap_endpoint(k, c)+1))
    cases.append((k, ap_endpoint(k, 34)+4))  # several quaternary carries
    for size, N in cases:
        if direct_size(witness(size, N)) != N:
            raise AssertionError(f'Direct sum count failed for {(size, N)}')
    print(f'Direct enumeration verified {len(cases)} integer witnesses.')

    # Exercise scaling, all four small-fringe shifts, and high cardinalities
    # at a larger k using the proven identities and cardinality of the output.
    size = 2000
    targets = [4*size-3, 4*size, 4*size+3, 4*size+6, 20*size-44,
               ap_endpoint(size, 1000)+1, comb(size+3, 4)]
    for N in targets:
        witness(size, N)
    print(f'Formula and point-count checks passed for {len(targets)} targets at k = {size}.')


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('pair', nargs='*', type=int, metavar='integer')
    parser.add_argument('--verify', action='store_true',
                        help='directly enumerate all unordered four-term sums of the witness')
    args = parser.parse_args()
    if not args.pair:
        self_test()
        return
    if len(args.pair) != 2:
        parser.error('Supply both k and N, or no arguments for the self-test.')
    k, N = args.pair
    if not allowed(k, N):
        parser.error('Choose k >= 5 and an allowed N in its fourfold spectrum.')
    A = witness(k, N)
    if args.verify:
        observed = direct_size(A)
        if observed != N:
            raise AssertionError(f'Expected {N}, obtained {observed}')
        method = 'direct enumeration'
    else:
        method = 'finite certificate' if k <= 36 else 'construction formula'
    print(f'k = {k}, |4A| = {N} ({method})')
    # Exact integer coordinates can legitimately have many decimal digits.
    if hasattr(sys, 'set_int_max_str_digits'):
        sys.set_int_max_str_digits(0)
    print(f'A = {A}')


if __name__ == '__main__':
    main()
