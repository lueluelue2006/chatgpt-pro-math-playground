"""Certify the fourfold sumset spectrum for 5 <= k <= 36 (Python 3.10+).

This finite certificate covers only k = 5,...,36. Run without arguments to
verify all 655360 admissible pairs, and to compare the mixed-radix formula
with direct sum enumeration on reproducible test cases. With two integer
arguments k N, print a k-element integer set A and check |4A| = N directly.
No third-party packages, data files or network are used.
"""
import argparse
from functools import cache
from itertools import combinations, combinations_with_replacement
from math import comb, prod
from random import Random


def target(k):
    low, high = 4*k - 3, comb(k+3, 4)
    interval = (1 << (high+1)) - (1 << low)
    exceptions = (4*k - 2, 4*k - 1, 4*k + 2)
    return interval ^ sum(1 << n for n in exceptions)


def sumsets(B):
    """Bit j of the h-th entry records whether j is a sum of h elements."""
    sets = [1]
    for _ in range(4):
        new_set = 0
        for x in B:
            new_set |= sets[-1] << x
        sets.append(new_set)
    return sets


def add_point(sets, x):
    extended = [1]
    for old in sets[1:]:
        extended.append(old | (extended[-1] << x))
    return extended


def profile(sets):
    return tuple(v.bit_count() for v in sets[2:])


def core_groups(max_k):
    """Yield (core size, dictionary from (|2B|, |3B|, |4B|) to a core B)."""
    # First family: all 5-subsets of [0,22] containing 0 and 1.
    small = {}
    for tail in combinations(range(2, 23), 3):
        B = (0, 1) + tail
        small[profile(sumsets(B))] = B
    yield 5, small
    # Second family: normalized prefixes of the ratio-three progression.
    for b in range(2, min(8, max_k)+1):
        B = tuple((3**i - 1)//2 for i in range(b))
        yield b, {profile(sumsets(B)): B}
    # Third family: a segment with <= 2 interior holes and one outlying point.
    for holes in range(3):
        for b in range(3, max_k+1):
            n = b-2+holes
            group = {}
            for removed in combinations(range(1, n), holes):
                prefix = tuple(x for x in range(n+1) if x not in removed)
                if not any(y == x+1 for x, y in zip(prefix, prefix[1:])):
                    continue
                base_sets = sumsets(prefix)
                for t in range(n+1, 4*n+2):
                    v = profile(add_point(base_sets, t))
                    group[v] = prefix + (t,)
            yield b, group


def two_outliers(k):
    """Fourth family: [0,n] together with t and u in the displayed ranges."""
    n = k-3
    prefix = tuple(range(n+1))
    base_sets = sumsets(prefix)
    for t in range(n+1, 4*n+2):
        one = add_point(base_sets, t)
        for u in range(t+1, 4*t+2):
            yield add_point(one, u)[4].bit_count(), prefix + (t,u)


def free_sizes(b, s, data):
    """Coefficients of degrees 2 and 4 in F_B(z)/(1-z)^s."""
    x, y, z = data
    p2 = x + s*b + comb(s+1, 2)
    p4 = z + s*y + comb(s+1, 2)*x + comb(s+2, 3)*b + comb(s+3, 4)
    return p2, p4


@cache
def cap_mask(k, l):
    """Bit lk-uk-v for 0 <= u <= l and 0 <= v <= l-u."""
    mask = 0
    for u in range(l+1):
        width = l-u
        mask |= ((1 << (width+1))-1) << (width*(k-1))
    return mask


def certify():
    targets = {k: target(k) for k in range(5, 37)}
    hits = {k: 0 for k in targets}
    for b, group in core_groups(max(targets)):
        for k in range(max(5,b), 37):
            if hits[k] == targets[k]:
                continue
            s = k-b
            marks = hits[k]
            for data in group:
                p2, p4 = free_sizes(b, s, data)
                for a in range(s+1):
                    l = s-a
                    shift = p4-a*p2+comb(a,2)-l*k
                    marks |= cap_mask(k, l) << shift
            hits[k] = marks
    for k, wanted in targets.items():
        if hits[k] != wanted:
            for N, _ in two_outliers(k):
                hits[k] |= 1 << N
                if hits[k] == wanted:
                    break
        if hits[k] != wanted:
            raise AssertionError(f'k={k}: unmatched mask {hits[k]^wanted:#x}')
    print('k      ', *targets)
    print('counts ', *(hits[k].bit_count() for k in targets))
    print('Verified k=5..36; exactly', sum(x.bit_count() for x in hits.values()),
          'admissible (k, |4A|) pairs.')


def construct(B, radices):
    """Clear denominators in (B-p) union {1/q_1,...,1/(q_1 ... q_s)}."""
    if not radices:
        return sorted(B)
    p = next(x for x in B if x+1 in B)
    remaining = prod(radices)
    A = [remaining*(x-p) for x in B]
    for q in radices:
        remaining //= q
        A.append(remaining)
    low = min(A)
    return sorted(x-low for x in A)


def direct_fourfold_size(A):
    return len({sum(v) for v in combinations_with_replacement(A, 4)})


def validate_radices():
    random = Random(360004)
    count = 0
    for k in range(5, 37):
        # Extremal degrees and a sparse core with all-equal or mixed radices.
        cases = [((0, 1), [5]*(k-2)), ((0, 1, 4, 13), [2+k%4]*(k-4))]
        # The randomized cores contain a consecutive pair away from zero;
        # translation tests the formula also when the translated core is signed.
        for _ in range(2):
            b = random.randrange(3, k+1)
            B = (0, 3, 4, *sorted(random.sample(range(6, 4*b+6), b-3)))
            cases.append((B, [random.randrange(2,6) for _ in range(k-b)]))
        for B, radices in cases:
            s = len(radices)
            p2, p4 = free_sizes(len(B), s, profile(sumsets(B)))
            a, u, v = (radices.count(q) for q in (2,3,4))
            predicted = p4-a*p2+comb(a,2)-u*k-v
            A = construct(B, radices)
            if len(set(A)) != k or direct_fourfold_size(A) != predicted:
                raise AssertionError((B, radices, predicted))
            count += 1
    print('Directly checked', count, 'mixed-radix constructions.')


def witness(k, N):
    if k not in range(5, 37) or N < 0 or not (target(k) >> N) & 1:
        raise ValueError('Requested pair is outside the certified spectrum.')
    for b, group in core_groups(k):
        if b > k:
            continue
        s = k-b
        for data, B in group.items():
            p2, p4 = free_sizes(b, s, data)
            for a in range(s+1):
                for u in range(s-a+1):
                    v = p4-a*p2+comb(a,2)-u*k-N
                    if v in range(s-a-u+1):
                        return construct(B, [2]*a+[3]*u+[4]*v+[5]*(s-a-u-v))
    for size, A in two_outliers(k):
        if size == N:
            return list(A)
    raise AssertionError('Missing witness')


def verify_witness(k, N):
    A = witness(k, N)
    actual = direct_fourfold_size(A)
    if len(set(A)) != k or actual != N:
        raise AssertionError('Direct verification failed')
    print(f'k = {k}, |4A| = {actual}, A = {A}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pair', nargs='*', type=int)
    args = parser.parse_args()
    if not args.pair:
        certify()
        validate_radices()
    elif len(args.pair) == 2:
        verify_witness(*args.pair)
    else:
        parser.error('Supply either no arguments or k N.')
