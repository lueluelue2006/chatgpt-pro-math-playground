#!/usr/bin/env python3
"""Independently check a generated projection graph and optional finite witness.

Usage: python3 check_projection.py GRAPH.tsv [WITNESS.txt]
Only Python's standard library is used. The square test scans all factors by
offset, unlike the C++ generator's newly-created-suffix test.
"""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import sys


def square_free(word):
    for period in range(1, len(word) // 2 + 1):
        run = 0
        for left, right in zip(word, word[period:]):
            run = run + 1 if left == right else 0
            if run >= period:
                return False
    return True


def read_graph(path):
    lines = Path(path).read_text().splitlines()
    n, m = map(int, lines[0].split())
    assert len(lines) == 1 + n + m
    labels = [None] * n
    for line in lines[1:1+n]:
        v, label = line.split()
        v = int(v)
        assert 0 <= v < n and labels[v] is None
        assert len(label) == 26 and set(label) <= set('012')
        labels[v] = label.encode()
    assert len(set(labels)) == n
    out = [[] for _ in labels]
    seen = set()
    for line in lines[1+n:]:
        u, v, label = line.split()
        u, v, label = int(u), int(v), label.encode()
        assert 0 <= u < n and 0 <= v < n
        assert labels[u][5:] == labels[v][:-5]
        assert label == labels[v][-5:]
        assert (u, v, label) not in seen
        seen.add((u, v, label))
        out[u].append((v, label))
    assert (n, m) == (96, 102)
    return out


def verify_graph(path):
    out = read_graph(path)
    current = [(v, b'') for v in range(len(out))]
    counts = []
    for depth in range(101):
        counts.append(len(current))
        if not current:
            break
        children = []
        for u, word in current:
            for v, label in out[u]:
                new = word + label
                if square_free(new):
                    children.append((v, new))
        current = children
    else:
        raise AssertionError('No finite empty layer was obtained')
    assert len(counts) == 50 and counts[48] == 42 and counts[49] == 0
    assert sum(counts) == 7260
    print('projection vertices=96 edges=102')
    print('square-free path counts:', counts)
    print('total=7260; maximum=48 edges=240 letters; layer 49 is empty')


def verify_witness(path):
    word = Path(path).read_bytes().strip()
    assert len(word) == 2000 and set(word) <= set(b'012')
    for step in (1, 5, 8):
        sample = word[::step]
        assert square_free(sample)
        print(f'witness step={step} length={len(sample)} square-free')
    digest = sha256(word).hexdigest()
    assert digest == 'b6a92b97b732b7657a60174ea80476ac1b82e1f13b48498d7742402000d5bed3'
    print('witness SHA-256:', digest)


if __name__ == '__main__':
    if len(sys.argv) not in (2, 3):
        raise SystemExit(__doc__)
    verify_graph(sys.argv[1])
    if len(sys.argv) == 3:
        verify_witness(sys.argv[2])
