#!/usr/bin/env python3
"""Check the finite structural obstruction on the absolute 8-track graph."""

from pathlib import Path
import sys


def verify_structure(out):
    """Each entry of out is a list of (destination, five-letter label)."""
    def reachable(x):
        visited = {x}
        stack = [x]
        while stack:
            for y, _ in out[stack.pop()]:
                if y not in visited:
                    visited.add(y)
                    stack.append(y)
        return visited

    reach = [reachable(x) for x in range(len(out))]
    components = {
        frozenset(y for y in targets if x in reach[y])
        for x, targets in enumerate(reach)
    }
    assert sorted(map(len, components)) == [12, 12, 12, 12, 48]
    macro = {}
    for component in components:
        for x in component:
            assert all(y in component for y, _ in out[x])
        if len(component) == 12:
            assert all(len(out[x]) == 1 for x in component)
            continue
        branch = {x for x in component if len(out[x]) != 1}
        assert len(branch) == 6
        assert all(len(out[x]) == 2 for x in branch)
        for x in branch:
            moves = []
            for y, word in out[x]:
                seen = set()
                while y not in branch:
                    assert y not in seen
                    seen.add(y)
                    (y, rest), = out[y]
                    word += rest
                moves.append((y, word))
            moves.sort(key=lambda pair: len(pair[1]))
            assert [len(word) for _, word in moves] == [10, 40]
            macro[x] = moves
    for x, ((a, short_word), (b, long_word)) in sorted(macro.items()):
        assert a != x and macro[a][0][0] == x
        assert b != x and macro[macro[b][1][0]][1][0] == x
        after_long_then_short = long_word + macro[b][0][1]
        root = after_long_then_short[6:26]
        assert root == after_long_then_short[26:46]
        if isinstance(root, bytes):
            root = root.decode()
        print(f'branch {x}: short -> {a}, long -> {b}, forbidden root {root}')
    print('four deterministic cycles; six branches; every long-short pair contains a square')


def main(path):
    lines = Path(path).read_text().splitlines()
    n, m = map(int, lines[0].split())
    assert len(lines) == 1 + n + m
    states = {}
    for line in lines[1:1+n]:
        identifier, word = line.split()
        assert len(word) == 26
        states[int(identifier)] = word
    assert len(states) == n
    out = [[] for _ in range(n)]
    for line in lines[1+n:]:
        left, right, word = line.split()
        x, y = int(left), int(right)
        assert states[x][5:] == states[y][:-5]
        assert word == states[y][-5:]
        out[x].append((y, word))
    verify_structure(out)


if __name__ == '__main__':
    main(sys.argv[1])
