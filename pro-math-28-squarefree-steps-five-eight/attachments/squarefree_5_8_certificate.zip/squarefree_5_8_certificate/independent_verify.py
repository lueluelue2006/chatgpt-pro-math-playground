"""Independently verify the 40-aligned obstruction for square-free steps 1, 5, 8.

Python 3, standard library only. Run without arguments to rebuild every graph.
Use --compare FILE to compare the final labeled graph with the C++ certificate.
"""

import argparse
import re
from functools import lru_cache
from itertools import permutations
from pathlib import Path


BLOCK = 40
STEPS = (1, 5, 8)
ALPHABET = bytes(range(3))
FORWARD = {}
INVERSE = {}
for ordering in permutations(ALPHABET):
    letters = bytes(ordering)
    FORWARD[letters[:2]] = bytes.maketrans(ALPHABET, letters)
    INVERSE[letters[:2]] = bytes.maketrans(letters, ALPHABET)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def initial_layers():
    words = [b'']
    for n in range(81):
        if n == 41:
            vertices = words
        changed = [d for d in STEPS if n % d == 0]
        children = []
        for w in words:
            for a in range(min(2, max(w, default=-1) + 1) + 1):
                child = w + bytes([a])
                for d in changed:
                    s = child[::d]
                    if any(s[-2 * p : -p] == s[-p:] for p in range(1, len(s) // 2 + 1)):
                        break
                else:
                    children.append(child)
        words = children
    return vertices, words


def components(out):
    """Return true strongly connected components using iterative Tarjan."""
    n = len(out)
    mark = [-1] * n
    low = [0] * n
    on_stack = bytearray(n)
    pending = []
    groups = []
    comp = [-1] * n
    number = 0
    for root in range(n):
        if mark[root] >= 0:
            continue
        mark[root] = low[root] = number
        number += 1
        pending.append(root)
        on_stack[root] = 1
        dfs = [(root, iter(out[root]))]
        while dfs:
            u, arcs = dfs[-1]
            edge = next(arcs, None)
            if edge is not None:
                v = edge[1]
                if mark[v] == -1:
                    mark[v] = low[v] = number
                    number += 1
                    pending.append(v)
                    on_stack[v] = 1
                    dfs.append((v, iter(out[v])))
                elif on_stack[v]:
                    low[u] = min(low[u], mark[v])
                continue
            dfs.pop()
            if dfs:
                parent = dfs[-1][0]
                low[parent] = min(low[parent], low[u])
            if low[u] == mark[u]:
                group = []
                while True:
                    v = pending.pop()
                    on_stack[v] = 0
                    comp[v] = len(groups)
                    group.append(v)
                    if v == u:
                        break
                groups.append(group)
    return comp, groups


@lru_cache(maxsize=None)
def square_pattern(p):
    # Digits are encoded as bytes 0, 1 and 2, none of which is a newline.
    return re.compile(rb'(.{' + str(p).encode() + rb'})\1')


@lru_cache(maxsize=None)
def crossing_ranges(n, b):
    # Known square-free intervals are [0,n-b) and [b,n). A new square
    # [i,i+2p) must have i<b and i+2p>n-b. Python's search end is exclusive.
    ranges = []
    for p in range(1, n // 2 + 1):
        lo = max(0, n - b + 1 - 2 * p)
        hi = min(b - 1, n - 2 * p)
        if lo <= hi:
            ranges.append((square_pattern(p), lo, hi + 2 * p))
    return ranges


def valid_join(w):
    for d in STEPS:
        s = w[::d]
        if any(rx.search(s, lo, end) for rx, lo, end in crossing_ranges(len(s), BLOCK // d)):
            return False
    return True


def projected_factors():
    vertices, edges = initial_layers()
    expected = [(92, 924), (477, 1908), (1272, 5224), (5224, 19200), (18096, 63696)]
    for k in range(1, 6):
        width = BLOCK * k + 1
        require((len(vertices), len(edges)) == expected[k - 1], f'wrong input at width {width}')
        ids = {w: i for i, w in enumerate(vertices)}
        out = [[] for _ in vertices]
        for i, e in enumerate(edges):
            suffix = e[BLOCK:]
            target = ids[suffix.translate(INVERSE[suffix[:2]])]
            out[ids[e[:width]]].append((i, target))
        comp, parts = components(out)
        live = []
        sizes = []
        for c, group in enumerate(parts):
            inside = sum(comp[v] == c for u in group for _, v in out[u])
            if inside > len(group):
                live.append((c, group))
                sizes.append((len(group), inside))
        print(f'Window {width}: {len(vertices)} vertices, {len(edges)} edges. Branching SCCs {sorted(sizes)}', flush=True)
        kept = []
        extended = []
        projected = set()
        for c, group in live:
            for u in group:
                for i, v in out[u]:
                    if comp[v] != c:
                        continue
                    e = edges[i]
                    if k == 5:
                        sample = e[::8]
                        projected.update(sample.translate(t) for t in FORWARD.values())
                        continue
                    kept.append(e)
                    undo_normalization = FORWARD[e[BLOCK : BLOCK + 2]]
                    for j, t in out[v]:
                        if comp[t] == c:
                            w = e + edges[j][-BLOCK:].translate(undo_normalization)
                            if valid_join(w):
                                extended.append(w)
        if k == 5:
            require(sorted(sizes) == [(252, 504), (252, 504), (5568, 20304)], 'wrong final core')
            print('Final branching core: 6072 vertices, 21312 edges.', flush=True)
            return projected
        vertices, edges = kept, extended


@lru_cache(maxsize=None)
def square_free(s):
    # Look for all square factors at every start, independently of the DFS implementation.
    return all(square_pattern(p).search(s) is None for p in range(1, len(s) // 2 + 1))


def check_paths(factors):
    edges = {(s[:-5], s[5:], s[-5:]) for s in factors}
    vertices = sorted({endpoint for u, v, _ in edges for endpoint in (u, v)})
    require((len(vertices), len(edges)) == (96, 102), 'wrong projected graph size')
    ids = {w: i for i, w in enumerate(vertices)}
    out = [[] for _ in vertices]
    for u, v, label in sorted(edges):
        out[ids[u]].append((label, ids[v]))
    comp, groups = components(out)
    scc_sizes = sorted((len(group), sum(comp[v] == c for u in group for _, v in out[u]))
                       for c, group in enumerate(groups))
    require(scc_sizes == [(12, 12)] * 4 + [(48, 54)], 'wrong projected components')
    print(f'Projection: 96 vertices, 102 edges. SCCs {scc_sizes}', flush=True)
    paths = [(u, b'') for u in range(len(vertices))]
    counts = []
    for number in range(50):
        counts.append(len(paths))
        if not paths:
            break
        children = []
        for u, s in paths:
            for label, v in out[u]:
                word = s + label
                if square_free(word):
                    children.append((v, word))
        paths = children
    require(len(counts) == 50 and counts[-1] == 0 and sum(counts) == 7260, 'wrong projected paths')
    print('All-factor search: 7260 square-free walks including empty walks, max 48 edges / 240 letters. Zero at 49 edges.', flush=True)
    return edges


def ascii_digits(w):
    return bytes(c + ord('0') for c in w)


def compare(path, edges):
    rows = Path(path).read_bytes().splitlines()
    n, m = map(int, rows[0].split())
    require((n, m, len(rows)) == (96, 102, 199), 'invalid TSV header or size')
    names = {}
    for line in rows[1 : n + 1]:
        i, w = line.split()
        names[int(i)] = w
    supplied = set()
    for row in rows[n + 1 :]:
        u, v, label = row.split()
        supplied.add((names[int(u)], names[int(v)], label))
    rebuilt = {(ascii_digits(u), ascii_digits(v), ascii_digits(w)) for u, v, w in edges}
    require(supplied == rebuilt, 'labeled projected edge sets differ')
    print('TSV matches all 102 labeled word-to-word transitions.', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compare', metavar='TSV', help='compare the fully rebuilt graph by actual vertex words')
    args = parser.parse_args()
    result = check_paths(projected_factors())
    if args.compare:
        compare(args.compare, result)
