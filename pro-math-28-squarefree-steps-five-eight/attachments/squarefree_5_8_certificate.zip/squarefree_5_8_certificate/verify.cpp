#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
constexpr int L=201, D=40, N=L+D;
struct Edge {int u,v; array<char,31> p8;};
struct Components {vector<int> id,size;};

Components scc(const vector<vector<int>>&g) {
 int n=int(g.size());vector<vector<int>> rev(n);
 for(int u=0;u<n;++u)for(int v:g[u])rev[v].push_back(u);
 vector<char>seen(n);vector<int>order;
 for(int root=0;root<n;++root)if(!seen[root]) {
  vector<pair<int,int>> stack={{root,0}};seen[root]=1;
  while(!stack.empty()) {
   int u=stack.back().first;int &i=stack.back().second;
   if(i==int(g[u].size())){order.push_back(u);stack.pop_back();continue;}
   int v=g[u][i++];if(!seen[v]){seen[v]=1;stack.emplace_back(v,0);}
  }
 }
 Components c;c.id.assign(n,-1);
 for(auto it=order.rbegin();it!=order.rend();++it)if(c.id[*it]<0) {
  int id=int(c.size.size());c.size.push_back(0);vector<int>stack={*it};c.id[*it]=id;
  while(!stack.empty()) {
   int u=stack.back();stack.pop_back();++c.size[id];
   for(int v:rev[u])if(c.id[v]<0){c.id[v]=id;stack.push_back(v);}
  }
 }
 return c;
}
bool no_new_square(const char*s,int n) {
 for(int k=1;2*k<=n;++k)
  if(s[n-1]==s[n-1-k] && memcmp(s+n-2*k,s+n-k,k)==0)return false;
 return true;
}
struct Enumerator {
 array<char,N>w{};array<char,(N+4)/5>a{};array<char,(N+7)/8>b{};
 array<uint64_t,N+1>counts{};
 unordered_map<string,int>ids;vector<Edge>edges;
 int target=L;bool collect_edges=false;
 void dfs(int n,int source=-1) {
  ++counts[n];
  if(n==L && collect_edges)source=ids.at(string(w.data(),L));
  if(n==target) {
   if(!collect_edges)ids.emplace(string(w.data(),L),int(ids.size()));
   else {
    array<char,3>inv{};inv[w[D]-'0']='0';inv[w[D+1]-'0']='1';
    inv[3-(w[D]-'0')-(w[D+1]-'0')]='2';
    string suffix;for(int i=D;i<N;++i)suffix+=inv[w[i]-'0'];
    Edge e;e.u=source;e.v=ids.at(suffix);
    for(int j=0;j<31;++j)e.p8[j]=w[8*j];
    edges.push_back(e);
   }
   return;
  }
  for(char x='0';x<='2';++x) {
   // Every admissible word of length >=2 has exactly one renaming starting 01.
   if((n==0&&x!='0')||(n==1&&x!='1'))continue;
   w[n]=x;if(!no_new_square(w.data(),n+1))continue;
   if(n%5==0){a[n/5]=x;if(!no_new_square(a.data(),n/5+1))continue;}
   if(n%8==0){b[n/8]=x;if(!no_new_square(b.data(),n/8+1))continue;}
   dfs(n+1,source);
  }
 }
};
int main(int argc,char**argv) {
 string prefix=argc>1?argv[1]:"direct";
 Enumerator en;en.dfs(0);
 cout<<"V201 "<<en.ids.size()<<endl;
 en.target=N;en.collect_edges=true;en.counts.fill(0);en.dfs(0);
 cout<<"E241 "<<en.edges.size()<<endl;
 uint64_t visits=0;for(auto x:en.counts)visits+=x;
 cout<<"prefix_visits "<<visits<<endl;
 ofstream counts(prefix+"_counts.csv");counts<<"length,normalized_count\n";
 for(int i=0;i<=N;++i)counts<<i<<','<<en.counts[i]<<'\n';
 int n=int(en.ids.size());vector<vector<int>>g(n);
 for(auto&e:en.edges)g[e.u].push_back(e.v);
 auto c=scc(g);vector<int>arcs(c.size.size());
 for(auto&e:en.edges)if(c.id[e.u]==c.id[e.v])++arcs[c.id[e.u]];
 int nv=0,ne=0,nc=0;
 for(int i=0;i<int(c.size.size());++i)if(arcs[i]>c.size[i]){
  ++nc;nv+=c.size[i];ne+=arcs[i];
  cout<<"branching_component "<<c.size[i]<<' '<<arcs[i]<<endl;
 }
 cout<<"branching_core "<<nv<<' '<<ne<<' '<<nc<<endl;
 int other_cyclic=0;
 for(int i=0;i<int(c.size.size());++i)if(arcs[i]==c.size[i])++other_cyclic;
 cout<<"other_cyclic_components "<<other_cyclic<<endl;
 // Projection is a conservative supergraph: merging equal 26-letter samples
 // may add walks, but cannot remove any actual projected walk.
 set<pair<string,string>>projected_edges;set<string>vertices;
 for(auto&e:en.edges) {
  int a=c.id[e.u];if(a!=c.id[e.v]||arcs[a]<=c.size[a])continue;
  string p="012";
  do {
   string v;for(char x:e.p8)v+=p[x-'0'];
   auto src=v.substr(0,26),dst=v.substr(5,26);
   vertices.insert(src);vertices.insert(dst);projected_edges.emplace(src,dst);
  } while(next_permutation(p.begin(),p.end()));
 }
 map<string,int>idx;for(auto&s:vertices)idx.emplace(s,int(idx.size()));
 vector<vector<pair<int,string>>>pg(idx.size());
 vector<vector<int>>ug(idx.size());
 ofstream graph(prefix+"_projection.tsv");
 graph<<idx.size()<<' '<<projected_edges.size()<<'\n';
 for(auto&[word,id]:idx)graph<<id<<' '<<word<<'\n';
 for(auto&[a,b]:projected_edges) {
  int u=idx.at(a),v=idx.at(b);string label=b.substr(21,5);
  pg[u].emplace_back(v,label);ug[u].push_back(v);
  graph<<u<<' '<<v<<' '<<label<<'\n';
 }
 cout<<"projection "<<idx.size()<<' '<<projected_edges.size()<<endl;
 auto pc=scc(ug);vector<int>pa(pc.size.size());
 for(int u=0;u<int(ug.size());++u)for(int v:ug[u])if(pc.id[u]==pc.id[v])++pa[pc.id[u]];
 for(int i=0;i<int(pc.size.size());++i)cout<<"projection_component "<<pc.size[i]<<' '<<pa[i]<<endl;
 // Exact finite search over this 96-state projection graph. Inspect every new
 // suffix after each emitted character. A complete output block has 5 letters.
 uint64_t paths=0;int max_letters=0;vector<uint64_t>hist(1001);
 function<void(int,const string&)> walk=[&](int u,const string&s) {
  ++paths;max_letters=max(max_letters,int(s.size()));
  if(s.size()>=hist.size()){cerr<<"unexpected long path\n";exit(4);}
  ++hist[s.size()];
  for(auto&[v,label]:pg[u]) {
   string t=s;bool valid=true;
   for(char x:label){t+=x;if(!no_new_square(t.data(),int(t.size()))){valid=false;break;}}
   if(valid)walk(v,t);
  }
 };
 for(int v=0;v<int(pg.size());++v)walk(v,"");
 cout<<"projection_search "<<paths<<' '<<max_letters<<endl;
 assert(max_letters%5==0);
 ofstream path_counts(prefix+"_path_counts.csv");path_counts<<"edges,square_free_paths\n";
 for(int i=0;i<=max_letters/5+1;++i)path_counts<<i<<','<<hist[5*i]<<'\n';
 uint64_t per_branch=max_letters/5;
 // In a normalized simple SCC with m vertices, at most 6m-1 full edges
 // are possible without a square (a symbol permutation has order <=3).
 // In each branching SCC, at most per_branch edges are possible.
 // Add <= number_of_components-1 transitions between SCCs.
 uint64_t impossible_edges=6*uint64_t(n-nv)+(per_branch+1)*uint64_t(nc);
 uint64_t impossible_length=L+D*impossible_edges;
 cout<<"coarse_impossible_length "<<impossible_length<<endl;
 // A sharper bound uses the condensation DAG instead of summing all SCCs.
 int C=int(c.size.size());vector<uint64_t>weight(C),dp(C);
 vector<vector<int>>dag(C);vector<int>indegree(C);
 for(int i=0;i<C;++i) {
  if(arcs[i]>c.size[i])weight[i]=per_branch;
  else if(arcs[i]==c.size[i])weight[i]=6*uint64_t(c.size[i])-1;
  else {assert(c.size[i]==1 && arcs[i]==0);weight[i]=0;}
  dp[i]=weight[i];
 }
 for(auto&e:en.edges)if(c.id[e.u]!=c.id[e.v])dag[c.id[e.u]].push_back(c.id[e.v]);
 for(auto&adj:dag){sort(adj.begin(),adj.end());adj.erase(unique(adj.begin(),adj.end()),adj.end());for(int v:adj)++indegree[v];}
 queue<int>q;for(int i=0;i<C;++i)if(!indegree[i])q.push(i);
 int processed=0;uint64_t max_edges=0;
 while(!q.empty()) {
  int u=q.front();q.pop();++processed;max_edges=max(max_edges,dp[u]);
  for(int v:dag[u]){dp[v]=max(dp[v],dp[u]+1+weight[v]);if(!--indegree[v])q.push(v);}
 }
 assert(processed==C);
 cout<<"condensation_components "<<C<<endl;
 cout<<"path_edge_upper_bound "<<max_edges<<endl;
 cout<<"impossible_length "<<L+D*(max_edges+1)<<endl;
 cout<<"VERIFIED: no infinite admissible word"<<endl;
}
