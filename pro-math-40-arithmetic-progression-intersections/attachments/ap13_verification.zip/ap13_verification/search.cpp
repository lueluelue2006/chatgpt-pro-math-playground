// Exact finite check for the intersection problem on {1,...,13}.
// C++17. Examples: ./verify pairs or ./verify long-pairs 0 4000
// "pairs" searches nonstarred 83-cliques containing a two-element set.
// "long-pairs" searches the minimum-size-three case using the two-edge lemma.
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <tuple>
#include <vector>

using Word = unsigned long long;
constexpr int N = 13, V = 1 << N, W = V / 64, TARGET = 83;
constexpr int PAIRS = N * (N - 1) / 2;
struct Bits { Word word[W]; };
struct Obligations { Word word[2]; };
struct Edge { int a, b, id, reflected_id, neighbors; };

bool is_ap[V], pair_mode;
int reflected[V], global_degree[V], local_degree[V], local_index[V];
int pair_mask[PAIRS], words;
Obligations hitting_pairs[V];
Bits global_graph[V], graph[V], containing[N], missing_pair[PAIRS];
std::vector<int> mask, selected;
Word nodes = 0, first_roots = 0, second_roots = 0;

int pop(Word x) { return __builtin_popcountll(x); }
void add(Bits& a, int i) { a.word[i / 64] |= 1ULL << (i % 64); }
void remove(Bits& a, int i) { a.word[i / 64] &= ~(1ULL << (i % 64)); }
bool has(const Bits& a, int i) { return (a.word[i / 64] >> (i % 64)) & 1; }
void clear(Bits& a) { std::memset(a.word, 0, words * sizeof(Word)); }
void intersect(Bits& r, const Bits& a, const Bits& b) {
    for (int i = 0; i < words; ++i) r.word[i] = a.word[i] & b.word[i];
}
int size(const Bits& a) {
    int result = 0;
    for (int i = 0; i < words; ++i) result += pop(a.word[i]);
    return result;
}
int common_size(const Bits& a, const Bits& b) {
    int result = 0;
    for (int i = 0; i < words; ++i) result += pop(a.word[i] & b.word[i]);
    return result;
}
Obligations both(Obligations a, Obligations b) {
    return {{a.word[0] & b.word[0], a.word[1] & b.word[1]}};
}
int edge_id(int a, int b) {
    if (a > b) std::swap(a, b);
    return a * V + b;
}

// Extract vertices and color greedily by repeatedly removing an independent set.
// A clique needing r vertices must use one of the vertices colored r or higher.
std::vector<int> color_tail(const Bits& p, int required) {
    Bits rest;
    std::memcpy(rest.word, p.word, words * sizeof(Word));
    int first = 0, color = 0;
    std::vector<int> tail;
    while (true) {
        while (first < words && !rest.word[first]) ++first;
        if (first >= words) return tail;
        ++color;
        Bits available;
        std::memcpy(available.word + first, rest.word + first,
                    (words - first) * sizeof(Word));
        for (int k = first; k < words; ++k) {
            while (available.word[k]) {
                int i = 64 * k + __builtin_ctzll(available.word[k]);
                remove(rest, i);
                remove(available, i);
                for (int h = k; h < words; ++h)
                    available.word[h] &= ~graph[i].word[h];
                if (color >= required) tail.push_back(i);
            }
        }
    }
}

// A vertex in an r-clique must have at least r-1 neighbors in the candidate set.
int peel(Bits& p, int count, int required) {
    bool changed = true;
    while (changed) {
        changed = false;
        for (int k = 0; k < words; ++k) {
            Word left = p.word[k];
            while (left) {
                int i = 64 * k + __builtin_ctzll(left);
                left &= left - 1;
                if (common_size(p, graph[i]) < required - 1) {
                    remove(p, i);
                    if (--count < required) return 0;
                    changed = true;
                }
            }
        }
    }
    return count;
}

bool search(Bits& p, int kernel, Obligations must_miss) {
    ++nodes;
    int required = TARGET - static_cast<int>(selected.size());
    if (!required) return kernel == 0;
    int count = size(p);
    if (count < required) return false;
    if (pair_mode && (count < 600 || selected.size() == 1)) {
        count = peel(p, count, required);
        if (count < required) return false;
    }
    auto tail = color_tail(p, required);
    if (tail.empty()) return false;

    // To finish nonstarred, every point common to the selected vertices must
    // be missed. In the special phase every transversal pair must be missed
    // too, by the already established result for the pair phase.
    Bits missing_point;
    const Bits* forced_group = nullptr;
    int best = V;
    for (int b = 0; b < N; ++b) if (kernel & (1 << b)) {
        int num = count - common_size(p, containing[b]);
        if (!num) return false;
        if (num < best) {
            best = num;
            for (int h = 0; h < words; ++h)
                missing_point.word[h] = ~containing[b].word[h];
            forced_group = &missing_point;
        }
    }
    if (!pair_mode) {
        for (int k = 0; k < 2; ++k) {
            Word left = must_miss.word[k];
            while (left) {
                int b = 64 * k + __builtin_ctzll(left);
                left &= left - 1;
                int num = common_size(p, missing_pair[b]);
                if (!num) return false;
                if (num < best) { best = num; forced_group = &missing_pair[b]; }
            }
        }
    }
    auto branch = [&](int i) {
        remove(p, i);
        Bits q;
        intersect(q, p, graph[i]);
        int m = mask[i];
        selected.push_back(m);
        if (search(q, kernel & m, both(must_miss, hitting_pairs[m]))) return true;
        selected.pop_back();
        return false;
    };
    // Both potential branch sets below hit every admissible completion.
    // The thresholds affect only which exhaustive partition gets used.
    bool use_forced = pair_mode ? (best <= 8 || (best < 30 && 8 * best < count))
                                : (2 * best < static_cast<int>(tail.size()));
    if (forced_group && use_forced) {
        for (int k = words - 1; k >= 0; --k) {
            Word left = p.word[k] & forced_group->word[k];
            while (left) {
                int i = 64 * k + 63 - __builtin_clzll(left);
                left ^= 1ULL << (i % 64);
                if (branch(i)) return true;
            }
        }
    } else {
        for (auto i = tail.rbegin(); i != tail.rend(); ++i)
            if (branch(*i)) return true;
    }
    return false;
}

// Compress the candidate neighborhood to local indices before coloring.
void prepare(const Bits& vertices) {
    words = W;
    mask.clear();
    for (int k = 0; k < W; ++k) {
        Word left = vertices.word[k];
        while (left) {
            int m = 64 * k + __builtin_ctzll(left);
            left &= left - 1;
            mask.push_back(m);
            local_degree[m] = common_size(global_graph[m], vertices);
        }
    }
    std::sort(mask.begin(), mask.end(), [](int x, int y) {
        return std::make_tuple(local_degree[x], global_degree[x], x) >
               std::make_tuple(local_degree[y], global_degree[y], y);
    });
    int n = static_cast<int>(mask.size());
    words = (n + 63) / 64;
    std::fill(local_index, local_index + V, -1);
    for (int i = 0; i < n; ++i) local_index[mask[i]] = i;
    for (auto& a : containing) clear(a);
    if (!pair_mode) for (auto& a : missing_pair) clear(a);
    for (int i = 0; i < n; ++i) {
        int m = mask[i];
        clear(graph[i]);
        for (int j = 0; j < n; ++j)
            if (has(global_graph[m], mask[j])) add(graph[i], j);
        for (int b = 0; b < N; ++b) if (m & (1 << b)) add(containing[b], i);
        if (!pair_mode) for (int b = 0; b < PAIRS; ++b)
            if (!(m & pair_mask[b])) add(missing_pair[b], i);
    }
}

bool run_pairs(int first, int last) {
    std::vector<int> pairs(pair_mask, pair_mask + PAIRS);
    std::sort(pairs.begin(), pairs.end(), [](int x, int y) {
        return std::make_tuple(global_degree[x], std::min(x, reflected[x]), x) <
               std::make_tuple(global_degree[y], std::min(y, reflected[y]), y);
    });
    Bits available{};
    for (int m = 1; m < V; ++m) if (pop(m) >= 2) add(available, m);
    for (int j = 0; j < PAIRS && j < last; ++j) {
        int a = pairs[j];
        remove(available, a);
        if (j < first || a > reflected[a]) continue;
        ++first_roots;
        words = W;
        Bits vertices;
        intersect(vertices, available, global_graph[a]);
        prepare(vertices);
        Bits p{};
        for (int i = 0; i < static_cast<int>(mask.size()); ++i) add(p, i);
        selected = {a};
        if (search(p, a, hitting_pairs[a])) return true;
    }
    return false;
}

bool run_special(std::vector<Edge>& edges, int first, int last) {
    words = W;
    for (auto& e : edges) e.neighbors = common_size(global_graph[e.a], global_graph[e.b]);
    std::sort(edges.begin(), edges.end(), [](const Edge& x, const Edge& y) {
        return std::make_tuple(x.neighbors, std::min(x.id, x.reflected_id), x.id) <
               std::make_tuple(y.neighbors, std::min(y.id, y.reflected_id), y.id);
    });
    std::vector<std::vector<int>> starts(V);
    for (int j = 0; j < static_cast<int>(edges.size()); ++j) starts[edges[j].a].push_back(j);
    for (int j = 0; j < static_cast<int>(edges.size()) && j < last; ++j) {
        const Edge& e = edges[j];
        // The first selected special edge partitions all answers. Clearing this
        // edge before intersecting its endpoints' neighborhoods has no effect.
        remove(global_graph[e.a], e.b);
        remove(global_graph[e.b], e.a);
        if (j < first || e.id > e.reflected_id) continue;
        words = W;
        Bits vertices;
        intersect(vertices, global_graph[e.a], global_graph[e.b]);
        if (size(vertices) < TARGET - 2) continue;
        ++first_roots;
        prepare(vertices);
        std::vector<int> possible;
        for (int m : mask) for (int k : starts[m])
            if (k > j && local_index[edges[k].b] >= 0) possible.push_back(k);
        std::sort(possible.begin(), possible.end());
        auto initial = both(hitting_pairs[e.a], hitting_pairs[e.b]);
        for (int k : possible) {
            const Edge& f = edges[k];
            int i = local_index[f.a], l = local_index[f.b];
            // Partition again by the first special edge among the remaining
            // 81 members. Previously processed edges have already been removed.
            Bits p;
            intersect(p, graph[i], graph[l]);
            remove(graph[i], l);
            remove(graph[l], i);
            ++second_roots;
            selected = {e.a, e.b, f.a, f.b};
            int kernel = e.a & e.b & f.a & f.b;
            auto must = both(initial, both(hitting_pairs[f.a], hitting_pairs[f.b]));
            if (search(p, kernel, must)) return true;
        }
    }
    return false;
}

int main(int argc, char** argv) {
    if (argc != 2 && argc != 4) {
        std::fprintf(stderr, "usage: %s pairs|long-pairs [first past-last]\n", argv[0]);
        return 2;
    }
    pair_mode = std::strcmp(argv[1], "pairs") == 0;
    if (!pair_mode && std::strcmp(argv[1], "long-pairs") != 0) return 2;
    int first = argc == 4 ? std::atoi(argv[2]) : 0;
    int last = argc == 4 ? std::atoi(argv[3]) : (pair_mode ? PAIRS : 15927);
    if (first < 0 || last < first) return 2;
    for (int a = 0; a < N; ++a) for (int d = 1; d < N; ++d) {
        int s = 0;
        for (int b = a; b < N; b += d) { s |= 1 << b; is_ap[s] = true; }
    }
    int np = 0;
    for (int a = 0; a < N; ++a) for (int b = a + 1; b < N; ++b)
        pair_mask[np++] = (1 << a) | (1 << b);
    for (int m = 1; m < V; ++m) {
        for (int b = 0; b < N; ++b) if (m & (1 << b)) reflected[m] |= 1 << (N - 1 - b);
        for (int b = 0; b < PAIRS; ++b) if (m & pair_mask[b])
            hitting_pairs[m].word[b / 64] |= 1ULL << (b % 64);
    }
    const int minimum_size = pair_mode ? 2 : 3;
    std::vector<Edge> edges;
    for (int a = 1; a < V; ++a) if (pop(a) >= minimum_size)
        for (int b = a + 1; b < V; ++b) if (pop(b) >= minimum_size && is_ap[a & b]) {
            add(global_graph[a], b); add(global_graph[b], a);
            ++global_degree[a]; ++global_degree[b];
            if (!pair_mode && pop(a & b) >= 6)
                edges.push_back({a, b, edge_id(a,b), edge_id(reflected[a],reflected[b]), 0});
        }
    if (!pair_mode && edges.size() != 15927) return 3;
    int total_roots = pair_mode ? PAIRS : static_cast<int>(edges.size());
    bool found = pair_mode ? run_pairs(first, last) : run_special(edges, first, last);
    if (found) {
        std::printf("FOUND");
        for (int m : selected) std::printf(" %d", m);
        std::printf("\n");
        return 1;
    }
    std::printf("%s UNSAT [%d,%d) of %d; first roots %llu; second roots %llu; nodes %llu\n",
                argv[1], first, std::min(last, total_roots), total_roots,
                first_roots, second_roots, nodes);
}
