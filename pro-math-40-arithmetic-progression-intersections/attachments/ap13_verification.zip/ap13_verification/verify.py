#!/usr/bin/env python3
"""Reproduce the n=13 arithmetic-progression-intersection certificate.

Standard-library Python plus a C++17 compiler are sufficient.
No network, numerical optimization, or third-party Python package is used.
Run: python3 verify.py --checks-only    (short finite algebra/coloring checks)
Run: python3 verify.py                  (also compile and run the exact searches)
"""
from argparse import ArgumentParser
from itertools import combinations
from math import gcd
from pathlib import Path
import subprocess
import tempfile
import time

N = 13
LIMIT = 1 << N


def is_ap(mask):
    if not mask:
        return False
    xs = [i for i in range(N) if mask >> i & 1]
    return len(xs) <= 2 or len({b - a for a, b in zip(xs, xs[1:])}) == 1


def ap_hull(mask):
    xs = [i for i in range(N) if mask >> i & 1]
    if len(xs) == 1:
        return mask
    step = gcd(*(x - xs[0] for x in xs[1:]))
    return sum(1 << x for x in range(xs[0], xs[-1] + 1, step))


def mask_of(xs):
    return sum(1 << (x - 1) for x in xs)


def construction():
    center = 7
    others = [x for x in range(1, 14) if x != center]
    family = {mask_of([center])}
    family.update(mask_of([center, x]) for x in others)
    family.update(mask_of([center, x, y]) for x, y in combinations(others, 2))
    for d in (1, 2, 3):
        family.remove(mask_of([center - 2*d, center, center + d]))
        family.remove(mask_of([center - d, center, center + 2*d]))
        for lo, hi in [(-2, 2), (-2, 1), (-1, 2)]:
            family.add(mask_of(center + j*d for j in range(lo, hi + 1)))
    assert len(family) == 82
    assert all(is_ap(a & b) for a, b in combinations(family, 2))
    print('Construction: 82 distinct nonempty sets; all 3321 intersections verified.', flush=True)
    return family


def star_coloring(center, ap, hull):
    """Construct and directly check a coloring of the compatibility graph's star."""
    bit = 1 << center
    bad_triples = [t for t in range(1, LIMIT)
                   if t & bit and t.bit_count() == 3 and not ap[t]]
    long_aps = [a for a in range(1, LIMIT)
                if a & bit and a.bit_count() >= 4 and ap[a]]
    eligible = {a: [t for t in bad_triples if a & t == t] for a in long_aps}
    owner = {}

    def augment(a, seen):
        for t in eligible[a]:
            if t in seen:
                continue
            seen.add(t)
            if t not in owner or augment(owner[t], seen):
                owner[t] = a
                return True
        return False

    for a in long_aps:
        augment(a, set())
    matched = {a: t for t, a in owner.items()}
    classes = {}
    for a in range(1, LIMIT):
        if not a & bit:
            continue
        if a.bit_count() <= 3:
            color = a
        elif ap[a]:
            color = matched.get(a, a)
        else:
            witnesses = [t for t in bad_triples
                         if a & t == t and a & hull[t] != hull[t]]
            assert witnesses, ('no private triple', center, a)
            color = witnesses[0]
        classes.setdefault(color, []).append(a)
    assert sum(map(len, classes.values())) == 4096
    # This direct test suffices to certify the bound, independently of the
    # matching algorithm and of any general private-triple theorem.
    for group in classes.values():
        for a, b in combinations(group, 2):
            assert not ap[a & b], ('bad color class', center, a, b)
    assert len(classes) <= 82
    return len(classes)


def rank_mod_two(rows):
    basis = {}
    for row in rows:
        while row:
            leading = row.bit_length() - 1
            if leading in basis:
                row ^= basis[leading]
            else:
                basis[leading] = row
                break
    return len(basis)


def finite_checks():
    family = construction()
    ap = [is_ap(a) for a in range(LIMIT)]
    assert sum(ap) == 204
    hull = [0] + [ap_hull(a) for a in range(1, LIMIT)]
    colors = [star_coloring(c, ap, hull) for c in range(N)]
    assert colors == [79,79,80,80,81,81,82,81,81,80,80,79,79]
    print('Star color counts:', colors, flush=True)

    small_aps = [a for a in range(1, LIMIT) if ap[a] and a.bit_count() <= 4]
    features = [0] + small_aps
    signs = [1 if t.bit_count() in (0, 2) else -1 for t in features]
    assert len(features) == 150 and signs.count(1) == 79
    minima = [LIMIT] * 14
    zero_counts = [0] * 14
    for a in range(1, LIMIT):
        value = sum(sign for t, sign in zip(features, signs) if a & t == t)
        size = a.bit_count()
        minima[size] = min(minima[size], value)
        zero_counts[size] += (value == 0)
        assert value >= 0
        assert (value == 0) == (ap[a] and size <= 5)
    assert minima[1:] == [0,0,0,0,0,1,1,2,3,4,5,7,8]
    assert zero_counts[1:6] == [13,78,36,22,15]
    print('Signed form: all 8191 diagonal signs verified exactly.', flush=True)
    print('Minimum values by member size 1..13:', minima[1:], flush=True)

    zeros = [a for a in range(1, LIMIT) if ap[a] and 3 <= a.bit_count() <= 5]
    rows = [sum(1 << j for j, t in enumerate(features) if a & t == t) for a in zeros]
    rank = rank_mod_two(rows)
    assert len(zeros) == rank == 73
    print('Zero-norm AP rows of sizes 3..5: 73 rows, rank 73 over F_2.', flush=True)
    print('These checks prove: minimum size >=3 and all intersections <=5 => family size <=79.', flush=True)
    return family


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--checks-only', action='store_true')
    parser.add_argument('--compiler', default='g++')
    args = parser.parse_args()
    start = time.monotonic()
    finite_checks()
    if args.checks_only:
        print('FINITE CHECKS PASSED. The two exact searches have not been run.', flush=True)
        return
    here = Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory(prefix='ap13_verify_') as temporary:
        exe = Path(temporary) / 'ap13_search'
        subprocess.run([args.compiler, '-O3', '-std=c++17', str(here / 'search.cpp'),
                        '-o', str(exe)], check=True)
        print('\nExact search 1: all families containing a two-element member.', flush=True)
        subprocess.run([str(exe), 'pairs'], check=True)
        print('\nExact search 2: ordered pairs of long-intersection pairs.', flush=True)
        subprocess.run([str(exe), 'long-pairs'], check=True)
    print('\nALL CHECKS PASSED: the exact maximum is 82.', flush=True)
    print('Elapsed seconds: %.2f' % (time.monotonic() - start), flush=True)


if __name__ == '__main__':
    main()
