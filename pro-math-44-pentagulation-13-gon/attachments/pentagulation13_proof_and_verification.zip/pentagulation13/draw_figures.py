import sys, json, math
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon

OUT = Path(__file__).resolve().parent
sys.path.insert(0,str(OUT))
from construct_verify import create, face_map

data=create()
(OUT/'pentagulation13_certificate.json').write_text(json.dumps(data,indent=2)+'\n')
_, adj, _=face_map(data['primal_faces'])

def harmonic(adj, boundary, phase=math.pi/2):
    # Counterclockwise, starting at the top of a circle.
    xy={v:np.array([math.cos(phase+2*math.pi*i/len(boundary)),
                    math.sin(phase+2*math.pi*i/len(boundary))])
        for i,v in enumerate(boundary)}
    inside=[v for v in adj if v not in xy]
    ix={v:i for i,v in enumerate(inside)}
    A=np.zeros((len(inside),len(inside))); B=np.zeros((len(inside),2))
    for v in inside:
        i=ix[v]; A[i,i]=len(adj[v])
        for w in adj[v]:
            if w in ix: A[i,ix[w]]-=1
            else: B[i]+=xy[w]
    X=np.linalg.solve(A,B)
    xy.update({v:X[ix[v]] for v in inside})
    return xy

def check_straight_embedding(adj,xy,faces,outer):
    edges=[(u,v) for u in adj for v in adj[u] if str(u)<str(v)]
    def cross(a,b,c):
        u=b-a;v=c-a
        return float(u[0]*v[1]-u[1]*v[0])
    def onseg(a,b,c):
        return abs(cross(a,b,c))<1e-10 and np.dot(c-a,c-b)<1e-10
    for i,(a,b) in enumerate(edges):
        for c,d in edges[i+1:]:
            if len({a,b,c,d})<4: continue
            p,q,r,s=[xy[z] for z in (a,b,c,d)]
            assert not(cross(p,q,r)*cross(p,q,s)<-1e-18 and cross(r,s,p)*cross(r,s,q)<-1e-18)
            assert not any([onseg(p,q,r),onseg(p,q,s),onseg(r,s,p),onseg(r,s,q)])
    areas={}
    for name,face in faces.items():
        pts=[xy[v] for v in face]
        area=sum(p[0]*q[1]-p[1]*q[0] for p,q in zip(pts,pts[1:]+pts[:1]))/2
        areas[name]=area
    assert abs(areas[outer])>0
    assert all(area*areas[outer]<0 for name,area in areas.items() if name!=outer)
    return {'minimum_edge_length':min(float(np.linalg.norm(xy[a]-xy[b])) for a,b in edges),
            'minimum_inner_face_area':min(abs(a) for k,a in areas.items() if k!=outer),
            'edge_crossings':0}

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'svg.fonttype':'none'})
p_xy=harmonic(adj,list(range(13)),math.pi/2-2*math.pi*6/13)
stats=check_straight_embedding(adj,p_xy,data['primal_faces'],'h')

def draw_primal(ax,labels=True):
    for name,face in data['primal_faces'].items():
        if name=='h': continue
        if name.startswith('pb') or name=='pc': color='#dce9f6'
        elif name.startswith('qb') or name=='qc': color='#dceee6'
        else: color='#f4f6f7'
        if name in ['pc','qc']: color='#fbe5aa'
        ax.add_patch(Polygon([p_xy[v] for v in face],facecolor=color,edgecolor='none',zorder=0))
    for u in adj:
        for v in adj[u]:
            if u>=v:continue
            pts=np.array([p_xy[u],p_xy[v]])
            boundary=(u<13 and v<13)
            ax.plot(pts[:,0],pts[:,1],color='#22405c' if boundary else '#536575',lw=2.1 if boundary else 1.15,zorder=1)
    for v,p in p_xy.items():
        color='#d47b27' if len(adj[v])>3 else '#22405c'
        ax.scatter(*p,s=25 if len(adj[v])>3 else 13,color=color,zorder=3)
        if labels:
            # The cyclic shell has natural outward labels; inner labels use white
            # masks so they remain distinct from fine edges.
            q=p*(1.055 if v<13 else 1)
            ax.text(*q,str(v),ha='center',va='center',fontsize=8.2,zorder=4,
                    bbox=dict(boxstyle='round,pad=0.12',fc='white',ec='none',alpha=.93))
    ax.set_aspect('equal');ax.set_xlim(-1.13,1.13);ax.set_ylim(-1.13,1.13);ax.axis('off')

fig,ax=plt.subplots(figsize=(10,10),dpi=200)
draw_primal(ax)
ax.set_title('A 13-gon with 27 pentagonal inner faces',fontsize=18,fontweight='bold',pad=12,color='#18354b')
fig.text(.5,.035,'48 vertices  |  74 edges  |  vertex connectivity 3\nOuter boundary: 0, 1, …, 12',ha='center',fontsize=11,color='#42586a')
fig.tight_layout(rect=(.02,.07,.98,.97))
fig.savefig(OUT/'pentagulation13.png',dpi=200,facecolor='white')
fig.savefig(OUT/'pentagulation13.svg',facecolor='white')
plt.close(fig)

_,d_adj,_=face_map(dict(enumerate(data['dual_faces'])))
disk={v:neigh-{'h'} for v,neigh in d_adj.items() if v!='h'}
cycle=[f'p{i}' for i in range(6)]+['w']+[f'q{i}' for i in reversed(range(6))]
xy=harmonic(disk,cycle,math.pi/2-2*math.pi*6/13)
labels={'w':r'$w$'}
for pr,cap in [('p','b'),('q','d')]:
    for i in range(6):
        labels[f'{pr}{i}']=rf'${pr}_{i}$'
        labels[f'{pr}b{i}']=rf'${cap}_{i}$'
    labels[f'{pr}c']=r'$c_P$' if pr=='p' else r'$c_Q$'
fig,ax=plt.subplots(figsize=(10,10),dpi=200)
for face in data['dual_faces'][13:]:
    color='#e8eff7' if any(v.startswith('p') for v in face) else '#e4f2e9'
    if len(face)==5: color='#fbefcf'
    if len(face)==4: color='#f9dfbf'
    ax.add_patch(Polygon([xy[v] for v in face],facecolor=color,edgecolor='none'))
for u in disk:
    for v in disk[u]:
        if u>=v: continue
        pts=np.array([xy[u],xy[v]])
        ax.plot(pts[:,0],pts[:,1],color='#476177',lw=1.3,zorder=1)
for u,p in xy.items():
    color='#22405c' if u in cycle else '#41816b'
    ax.scatter(*p,s=22,color=color,zorder=2)
    q=p*(1.065 if u in cycle else 1)
    ax.text(*q,labels[u],fontsize=12,ha='center',va='center',zorder=3,
            bbox=dict(boxstyle='round,pad=0.13',fc='white',ec='none',alpha=.93))
ax.set_title('The construction inside the 13-cycle',fontsize=18,fontweight='bold',pad=12,color='#18354b')
ax.set_aspect('equal');ax.set_xlim(-1.15,1.15);ax.set_ylim(-1.15,1.15);ax.axis('off')
fig.text(.5,.035,'This is H minus h. Add h outside the cycle and join it to all 13 boundary vertices.\nThe two interior patches are mirror copies.',ha='center',fontsize=11,color='#42586a')
fig.tight_layout(rect=(.02,.07,.98,.97))
fig.savefig(OUT/'dual_construction.png',dpi=200,facecolor='white')
fig.savefig(OUT/'dual_construction.svg',facecolor='white')
plt.close(fig)
(OUT/'drawing_checks.json').write_text(json.dumps(stats,indent=2)+'\n')
print(json.dumps(stats,indent=2))
