"""Reproduce the lower bound using the official plantri 5.8 generator.

Requires Python 3 and gcc or clang on PATH. No Python packages or network
access are needed. The unmodified official source archive is bundled.
Run: python3 verify_lower_bound_plantri.py
"""
from pathlib import Path
from itertools import combinations
import hashlib
import json
import re
import shutil
import subprocess
import tarfile
import tempfile

HERE = Path(__file__).resolve().parent
PLUGIN = '''
#define FILTER degree_filter
#define SUMMARY report_total
static unsigned long long all_count = 0;
static int degree_filter(int nbtot, int nbop, int doflip)
{
    int i;
    ++all_count;
    for (i = 0; i < nv; ++i) if (degree[i] >= 13) return 1;
    return 0;
}
static void report_total(void)
{
    fprintf(stderr,"ALL_TRIANGULATIONS=%llu\\n",all_count);
}
'''

def deletion_sets(rotation, residual):
    """All edge subsets with the specified incident degrees.

    Finalize one positive-degree vertex. A removed edge must join two
    vertices with positive remaining demand. Every possible selection of
    its neighbors is examined, so no feasible deletion set is omitted.
    """
    live = [v for v,d in enumerate(residual) if d]
    if not live:
        yield []
        return
    options = {u:[v for v in rotation[u] if residual[v]] for u in live}
    if any(len(options[u]) < residual[u] for u in live):
        return
    u = min(live,key=lambda v:len(options[v])-residual[v])
    for neighbors in combinations(options[u],residual[u]):
        after = residual[:]
        after[u] = 0
        for v in neighbors:
            after[v] -= 1
        for rest in deletion_sets(rotation,after):
            yield [(u,v) for v in neighbors] + rest

def separating_set(adj):
    for k in (0,1,2):
        for deleted in combinations(range(len(adj)),k):
            left = set(range(len(adj))).difference(deleted)
            queue = [min(left)]
            left.remove(queue[0])
            for u in queue:
                fresh = set(adj[u]) & left
                queue.extend(fresh)
                left -= fresh
            if left:
                return deleted
    return None

def main():
    compiler = shutil.which('gcc') or shutil.which('clang')
    if compiler is None:
        raise SystemExit('A C compiler (gcc or clang) is required for this optional check.')
    archive = HERE/'plantri58.tar.gz'
    print('Source: https://users.cecs.anu.edu.au/~bdm/plantri/plantri58.tar.gz')
    print('SHA256:',hashlib.sha256(archive.read_bytes()).hexdigest())
    results = []
    with tempfile.TemporaryDirectory(prefix='plantri_check_',dir=HERE) as tmp:
        folder = Path(tmp)
        with tarfile.open(archive) as tar:
            for member in tar.getmembers():
                target = (folder/member.name).resolve()
                if folder.resolve() not in target.parents:
                    raise ValueError('Unsafe archive member: '+member.name)
            if hasattr(tarfile, 'data_filter'):
                tar.extractall(folder,filter='data')
            else:
                tar.extractall(folder)
        source = folder/'plantri58'
        (source/'filter13.c').write_text(PLUGIN)
        exe = source/'plantri13'
        subprocess.run([compiler,'-O2','-DPLUGIN=filter13.c','-o',str(exe),
                        'plantri.c'],cwd=source,check=True)
        for p in (19,21,23,25):
            n = p+1
            run = subprocess.run([str(exe),'-m5','-a',str(n)],cwd=source,
                                 text=True,capture_output=True,check=True)
            all_count = int(re.search(r'ALL_TRIANGULATIONS=(\d+)',run.stderr).group(1))
            lines = run.stdout.splitlines()
            factor_count = valid_count = 0
            rejected = []
            for index,line in enumerate(lines):
                order,body = line.split()
                rotation = [[ord(c)-97 for c in row] for row in body.split(',')]
                assert len(rotation) == int(order) == n
                for hub,row in enumerate(rotation):
                    if len(row) < 13:
                        continue
                    demands = [len(row)-(13 if u==hub else 5)
                               for u,row in enumerate(rotation)]
                    assert min(demands)>=0 and sum(demands)==p-19
                    for removed in deletion_sets(rotation,demands):
                        factor_count += 1
                        absent = {frozenset(e) for e in removed}
                        adj = [[v for v in row if frozenset((u,v)) not in absent]
                               for u,row in enumerate(rotation)]
                        cut = separating_set(adj)
                        if cut is None:
                            valid_count += 1
                        else:
                            rejected.append({'triangulation_index':index,'hub':hub,
                                             'deleted_edges':removed,'vertex_cut':cut})
            result = {'bounded_faces':p,'dual_vertices':n,
                      'all_min_degree_5_triangulations':all_count,
                      'triangulations_with_max_degree_at_least_13':len(lines),
                      'degree_correct_edge_deletions':factor_count,
                      'three_connected_results':valid_count,
                      'rejected_candidates':rejected}
            results.append(result)
            print(json.dumps(result),flush=True)
    expected = [(73,0,0),(651,0,0),(7290,0,0),(91441,10,3)]
    for r,e in zip(results,expected):
        assert (r['all_min_degree_5_triangulations'],
                r['triangulations_with_max_degree_at_least_13'],
                r['degree_correct_edge_deletions']) == e
        assert r['three_connected_results'] == 0
    (HERE/'lower_bound_plantri_results.json').write_text(json.dumps(results,indent=2)+'\n')
    print('PASS: 19, 21, 23 and 25 bounded pentagonal faces are all impossible.')

if __name__ == '__main__':
    main()
