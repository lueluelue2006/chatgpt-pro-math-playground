41 点围长五的忠实单位距离图

完整中文证明：proof_zh.txt
主验证器：python3 verify_41.py
独立精细证书：python3 verify_41_fine.py
手工颜色论证核验：python3 verify_color_argument.py

三个脚本均只需 Python 标准库，无须联网。
完整整数中心、边集、着色：construction.json
示意图：construction.png / construction.svg
运行输出：verification_output.txt
文件校验和：SHA256SUMS.txt

点集由整数平方距离方程在指定有理盒内的唯一实根定义。
表中中心是定位数据，精确点不是把中心小数直接当作答案。
结论：41 个不同点，79 条且仅有这些单位距离边，围长 5，色数 4。
