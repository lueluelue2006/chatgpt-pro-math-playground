"""Verify a 41-point faithful unit-distance graph of girth 5 and chromatic number 4.

Run with Python 3.8 or newer. Only the standard library is used. Every
certificate check uses integers. The unknown coordinates lie in unit-radius
boxes around the integer centres below, in units of 1/100000.
"""

from fractions import Fraction
from itertools import combinations


SCALE = 100_000
CENTRES = [
    (0, 0), (172634, 76774), (74993, 88864), (76433, 94963),
    (101704, -1485), (100603, -27755), (100435, 115), (100000, 0),
    (73314, 88421), (84601, -10673), (99975, -2226), (5212, 24768),
    (199542, -13223), (72989, 68357), (2089, 18228), (172987, 68936),
    (140256, -93754), (165080, 48683), (35173, -76141), (74646, 96732),
    (99676, -8042), (63044, -26799), (162496, 133843), (72750, 94716),
    (147934, 29233), (161814, 6902), (145985, 29840), (145690, 29500),
    (73855, 87553), (138972, 12010), (146923, 27646), (53407, -3395),
    (235402, 74613), (84882, 70787), (54508, -10558), (167201, 127564),
    (231743, -25320), (172068, 106375), (134979, -69925), (70276, 95171),
    (149950, 22672),
]
PINNED = (0, 7)


def check(condition, message):
    if not condition:
        raise ArithmeticError(message)


def differences(a, b):
    return [x-y for x, y in zip(CENTRES[a], CENTRES[b])]


def centre_residual(a, b):
    return sum(d*d for d in differences(a, b)) - SCALE**2


def intended_edges():
    return {
        (a, b) for a, b in combinations(range(len(CENTRES)), 2)
        if 10_000 * abs(centre_residual(a, b)) < SCALE**2
    }


def inverse_numerator(matrix):
    """Return integers B and d > 0 such that B times matrix equals d times I."""
    n = len(matrix)
    m = [r[:] + [int(i == j) for j in range(n)] for i, r in enumerate(matrix)]
    denominator = 1
    for k in range(n):
        pivot_row = next((i for i in range(k, n) if m[i][k]), None)
        check(pivot_row is not None, "Singular matrix")
        m[k], m[pivot_row] = m[pivot_row], m[k]
        pivot = m[k][k]
        for i, row in enumerate(m):
            if i == k:
                continue
            coefficient = row[k]
            for j in range(k + 1, 2*n):
                value = pivot * row[j] - coefficient * m[k][j]
                row[j] = value // denominator
            row[k] = 0
        denominator = pivot
    numerators = [r[n:] for r in m]
    if denominator < 0:
        numerators = [[-x for x in r] for r in numerators]
        denominator = -denominator
    # This identity alone verifies the result of fraction-free elimination.
    columns = [[(i, row[j]) for i, row in enumerate(matrix) if row[j]]
               for j in range(n)]
    for i, row in enumerate(numerators):
        for j, column in enumerate(columns):
            value = sum(row[k] * entry for k, entry in column)
            check(value == (denominator if i == j else 0), "Inverse identity failed")
    return numerators, denominator


def verify_realisation(edges):
    # Write F_ab(z) = (z_ax-z_bx)^2 + (z_ay-z_by)^2 - SCALE^2,
    # with points 0 and 7 pinned. The free coordinates satisfy F(z) = 0.
    free = [i for i in range(len(CENTRES)) if i not in PINNED]
    cols = {i: 2*j for j, i in enumerate(free)}
    equations = sorted(edges - {PINNED})
    n = 2 * len(free)
    check(len(equations) == n == 78, "Unexpected system size")
    check(centre_residual(*PINNED) == 0, "Wrong pinned distance")
    jacobian, residuals = [], []
    for a, b in equations:
        dx, dy = differences(a, b)
        row = [0]*n
        for vertex, sign in ((a, 1), (b, -1)):
            if vertex in cols:
                j = cols[vertex]
                row[j], row[j+1] = sign * 2*dx, sign * 2*dy
        jacobian.append(row)
        residuals.append(centre_residual(a, b))

    # Work throughout in integer grid units, so the cube has radius 1.
    # The derivative of each edge equation has at most four nonzero
    # entries. Each changes by at most 4 on the cube. Consequently
    # T(z) = z - J(centre)^(-1) F(z) has Lipschitz constant <= q.
    inverse, denominator = inverse_numerator(jacobian)
    norm = max(sum(abs(x) for x in row) for row in inverse)
    step = max(abs(sum(x * f for x, f in zip(row, residuals))) for row in inverse)
    eta = Fraction(step, denominator)
    q = Fraction(16*norm, denominator)
    check(eta + q < 1, "Contraction failed")
    # T maps the closed cube into itself, since ||T(z)-centre|| <= eta+q.
    # Its unique fixed point there solves F=0, since J(centre) is invertible.
    return eta, q


def verify_distances(edges):
    target = SCALE**2
    minimum_separation = target
    minimum_gap = target
    for a, b in combinations(range(len(CENTRES)), 2):
        dx, dy = map(abs, differences(a, b))
        lower = max(0, dx-2)**2 + max(0, dy-2)**2
        upper = (dx+2)**2 + (dy+2)**2
        minimum_separation = min(minimum_separation, lower)
        if (a, b) not in edges:
            check(upper < target or target < lower, "Undecided nonedge")
            minimum_gap = min(minimum_gap, max(target-upper, lower-target))
    check(minimum_separation > 0, "Possible coincident points")
    return Fraction(minimum_separation, target), Fraction(minimum_gap, target)


def graph_neighbors(edges):
    adjacent = [set() for _ in CENTRES]
    for a, b in edges:
        adjacent[a].add(b)
        adjacent[b].add(a)
    return adjacent


def find_five_cycle(adjacent):
    for a, b in combinations(range(len(adjacent)), 2):
        count = len(adjacent[a] & adjacent[b])
        check(count < 2 and (a not in adjacent[b] or count == 0), "Short cycle")
    def extend(path):
        if len(path) == 5:
            return path if path[0] in adjacent[path[-1]] else None
        for v in sorted(adjacent[path[-1]] - set(path)):
            result = extend(path + [v])
            if result:
                return result
        return None
    for a in range(len(adjacent)):
        result = extend([a])
        if result:
            return result
    raise ArithmeticError("No five-cycle")


def coloring(adjacent, k):
    vertices = set(range(len(adjacent)))
    # Colors at the pinned edge can be prescribed by permuting their names.
    assigned = {PINNED[0]: 0, PINNED[1]: 1}
    nodes = 0
    def extend():
        nonlocal nodes
        nodes += 1
        if len(assigned) == len(vertices):
            return True
        uncolored = vertices - assigned.keys()
        forbidden = {w: {assigned[j] for j in adjacent[w] if j in assigned}
                     for w in uncolored}
        v = max(uncolored, key=lambda w: (len(forbidden[w]),
                                          len(adjacent[w] & uncolored), -w))
        for color in range(k):
            if color not in forbidden[v]:
                assigned[v] = color
                if extend():
                    return True
                del assigned[v]
        return False
    if not extend():
        return None, nodes
    return [assigned[i] for i in range(len(adjacent))], nodes


def main():
    edges = intended_edges()
    check(len(CENTRES) == 41 and len(edges) == 79, "Wrong graph size")
    eta, q = verify_realisation(edges)
    separation, gap = verify_distances(edges)
    check(eta < Fraction(1, 2), "Stated displacement bound failed")
    check(q < Fraction(5, 12), "Stated Lipschitz bound failed")
    check(separation > Fraction(1, 50_000), "Stated separation bound failed")
    check(gap > Fraction(1, 4_000), "Stated nonedge bound failed")
    adjacent = graph_neighbors(edges)
    cycle = find_five_cycle(adjacent)
    three, nodes = coloring(adjacent, 3)
    check(three is None, "A three-coloring exists")
    four, _ = coloring(adjacent, 4)
    check(four is not None and all(four[a] != four[b] for a, b in edges),
          "Four-coloring failed")
    # Print decimal bounds using explicit outward rounding.
    digits = 10**8
    def upper(x):
        return f"{-(-digits*x.numerator//x.denominator)/digits:.8f}"
    def lower(x):
        return f"{(digits*x.numerator//x.denominator)/digits:.8f}"
    print("Vertices = 41, edges = 79, free coordinates = 78")
    print("Centre displacement bound (grid units) <=", upper(eta))
    print("Lipschitz constant <=", upper(q))
    print("Sum of displacement and Lipschitz bounds <=", upper(eta + q))
    print("Minimum squared separation >=", lower(separation))
    print("Minimum squared-distance gap from 1 among nonedges >=", lower(gap))
    print("Girth = 5, witnessed by", cycle)
    print("Three-coloring search nodes =", nodes, "(no solution)")
    print("A four-coloring is", "".join(map(str, four)))


if __name__ == "__main__":
    main()
