#!/usr/bin/env python3
"""Verify a 41-point faithful unit-distance graph of girth five and chromatic number four.

Run with Python 3 and its standard library. All graph operations, matrix
calculations, and inequality checks use integers or rational numbers.
Fixed-point Gaussian elimination constructs an inverse candidate B.

The real coordinates are defined as the unique zero, in the box of coordinate
radius 10**-9 about CENTER/S, of the 78 squared-edge-length equations apart
from the fixed edge (0, 7). Points 0 and 7 are fixed at (0, 0) and (1, 0).
"""
from fractions import Fraction
from itertools import combinations

S = 10**15
B_DEN = 10**9
RADIUS = Fraction(1, 10**9)
PIN = (0, 7)
CENTER = [
    (0, 0),
    (1726336577596849, 767743539487339),
    (749927046184266, 888642183948064),
    (764334400721704, 949633500803580),
    (1017041752369546, -14845044189525),
    (1006032211399802, -277546094688511),
    (1004353681077506, 1151625171328),
    (1000000000000000, 0),
    (733142104561319, 884211297822754),
    (846011847042988, -106730967711121),
    (999752198507139, -22260763242595),
    (52115502786594, 247676065182232),
    (1995417982721528, -132233344022532),
    (729885517554139, 683569404862979),
    (20894727906044, 182282758406042),
    (1729868764128173, 689357890956510),
    (1402564230542969, -937543488332043),
    (1650797608110520, 486834427829214),
    (351726026370144, -761407154625011),
    (746455055925789, 967323607348857),
    (996761429833925, -80415495990696),
    (630438055541687, -267989947200755),
    (1624958102554569, 1338434030976501),
    (727496607606480, 947160454785004),
    (1479342876297366, 292326844175047),
    (1618142308605403, 69015918520697),
    (1459850671339860, 298404222692707),
    (1456900870783598, 295001362698797),
    (738549466460598, 875530445056034),
    (1389723995695375, 120098194708490),
    (1469228688321499, 276464159552827),
    (534070108324731, -33954313922310),
    (2354023042689700, 746127094919046),
    (848817660532714, 707873951160058),
    (545083162263508, -105576475284618),
    (1672007762322904, 1275639797539229),
    (2317434074657688, -253203304607733),
    (1720677341907552, 1063745312348852),
    (1349792148838633, -699245951445584),
    (702760617715579, 951714754295546),
    (1499497538390809, 226717658633252),
]

# Remove edge (2, 18) from the unique 40-edge member of Gordon Royle's
# enumeration of 21-vertex 4-chromatic graphs of girth at least five.
HALF_EDGES = [
    (0, 7), (1, 8), (2, 9), (0, 10), (3, 10), (3, 11), (4, 11),
    (5, 12), (6, 12), (0, 13), (1, 13), (5, 13), (6, 14), (8, 14),
    (10, 14), (2, 15), (3, 15), (6, 15), (13, 15), (4, 16), (9, 16),
    (10, 16), (12, 16), (3, 17), (5, 17), (8, 17), (9, 17), (4, 18),
    (7, 18), (14, 18), (1, 19), (6, 19), (7, 19), (11, 19), (0, 20),
    (2, 20), (8, 20), (11, 20), (12, 20),
]
PIVOT, TIP = 2, 18


def check(condition, message):
    if not condition:
        raise ArithmeticError(message)


def second(v):
    if v == PIVOT:
        return v
    return v + (21 if v < PIVOT else 20)


def edge(u, v):
    return tuple(sorted((u, v)))


EDGES = set(HALF_EDGES) | {edge(second(u), second(v)) for u, v in HALF_EDGES}
EDGES.add(edge(TIP, second(TIP)))


def adjacency(n, edges):
    neighbors = [set() for _ in range(n)]
    for u, v in edges:
        neighbors[u].add(v)
        neighbors[v].add(u)
    return neighbors


def graph_checks():
    n = len(CENTER)
    check((n, len(EDGES)) == (41, 79), 'wrong graph size')
    neighbors = adjacency(n, EDGES)
    for u, v in combinations(range(n), 2):
        common = neighbors[u] & neighbors[v]
        check(len(common) <= 1, 'four-cycle')
        check(not (v in neighbors[u] and common), 'triangle')
    cycle = [0, 7, 18, 14, 10]
    check(all(edge(u, v) in EDGES for u, v in zip(cycle, cycle[1:] + cycle[:1])),
          'five-cycle witness failed')
    # The symmetry of the three colors lets us fix the colors at the ends of
    # edge (0, 7). Enumerate every resulting coloring of the 21-vertex gadget.
    base = adjacency(21, HALF_EDGES)
    colors = [-1] * 21
    colors[0], colors[7] = 0, 1
    count = 0
    example = None

    def visit():
        nonlocal count, example
        remaining = [v for v in range(21) if colors[v] < 0]
        if not remaining:
            check(colors[PIVOT] == colors[TIP], 'unequal tips in a three-coloring')
            count += 1
            if example is None:
                example = colors.copy()
            return
        choices = {v: {0, 1, 2} - {colors[w] for w in base[v]} for v in remaining}
        v = min(remaining, key=lambda x: (len(choices[x]), -len(base[x]), x))
        for color in sorted(choices[v]):
            colors[v] = color
            visit()
            colors[v] = -1

    visit()
    check(count > 0, 'could not find a coloring of the gadget')
    colors4 = [-1] * n
    for v in range(21):
        colors4[v] = example[v]
        colors4[second(v)] = example[v]
    colors4[second(TIP)] = 3
    check(set(colors4) == {0, 1, 2, 3}, 'color witness label error')
    check(all(colors4[u] != colors4[v] for u, v in EDGES), 'improper four-coloring')
    # A three-coloring of the full graph would give both tips the color of the
    # common pivot, contradicting the edge between these tips.
    print('Girth = 5. Chromatic number = 4.')
    print('Gadget colorings fixing the colors of edge (0,7) =', count)
    print('Four-coloring, in vertex order =', ''.join(map(str, colors4)))


def equations():
    n = len(CENTER)
    check(CENTER[PIN[0]] == (0, 0) and CENTER[PIN[1]] == (S, 0), 'bad pin')
    variables = {pair: k for k, pair in enumerate(
        (v, axis) for v in range(n) if v not in PIN for axis in (0, 1))}
    jac = []
    residual = []
    for u, v in sorted(EDGES - {PIN}):
        delta = [CENTER[u][axis] - CENTER[v][axis] for axis in (0, 1)]
        residual.append(sum(x*x for x in delta) - S*S)
        row = [0] * len(variables)
        for axis, d in enumerate(delta):
            for name, value in [((u, axis), 2*d), ((v, axis), -2*d)]:
                if name in variables:
                    row[variables[name]] = value
        jac.append(row)
    check(len(jac) == len(variables) == 78, 'equation count mismatch')
    return jac, residual


def approximate_inverse(jac):
    # Jac is the integer numerator of J(c), whose denominator is S. Do
    # Gaussian elimination with 30 fixed decimal places. Its output merely
    # proposes a rational B, which root_check validates independently.
    scale = 10**30
    k = len(jac)
    rows = [[a * scale // S for a in row] +
            [scale * (i == j) for j in range(k)] for i, row in enumerate(jac)]
    for j in range(k):
        i = max(range(j, k), key=lambda h: abs(rows[h][j]))
        rows[i], rows[j] = rows[j], rows[i]
        pivot = rows[j][j]
        check(pivot != 0, 'inverse candidate pivot failed')
        rows[j] = [value * scale // pivot for value in rows[j]]
        for i in range(k):
            if i == j or rows[i][j] == 0:
                continue
            factor = rows[i][j]
            rows[i] = [x - (factor*y // scale) for x, y in zip(rows[i], rows[j])]
    return [[(B_DEN*x) // scale for x in row[k:]] for row in rows]


def root_check():
    jac, residual = equations()
    b = approximate_inverse(jac)
    k = len(b)
    sparse_j = [[(j, a) for j, a in enumerate(row) if a] for row in jac]
    largest_row = 0
    for i, row in enumerate(b):
        error = [0] * k
        error[i] = B_DEN * S
        for coefficient, entries in zip(row, sparse_j):
            for j, a in entries:
                error[j] -= coefficient*a
        largest_row = max(largest_row, sum(map(abs, error)))
    beta = Fraction(largest_row, B_DEN*S)
    bnorm = Fraction(max(sum(map(abs, row)) for row in b), B_DEN)
    eta = Fraction(max(abs(sum(m*f for m, f in zip(row, residual))) for row in b),
                   B_DEN*S*S)
    # Each row of J is supported on at most four entries. Moving any coordinate
    # by at most r changes each derivative by at most 4r. Thus for all x in the
    # box, ||I-BJ(x)|| <= beta + 16*r*||B|| in the infinity matrix norm.
    q = beta + 16*RADIUS*bnorm
    check(beta < Fraction(1, 10**6) and bnorm < 2600, 'matrix bound')
    check(eta < Fraction(1, 10**12) and q < Fraction(1, 20000), 'contraction bound')
    check(eta + q*RADIUS < RADIUS, 'ball not mapped into itself')
    # beta < 1 makes BJ(c), hence B, invertible. x -> x - B F(x) maps the
    # closed box into itself and contracts there. Its unique fixed point is
    # the unique root of F in the box, by Banach's fixed-point theorem.
    print('Exact rational bounds at the center and on the box:')
    print('  ||I - B J(c)||_infinity < 10^-6')
    print('  ||B||_infinity < 2600')
    print('  ||B F(c)||_infinity < 10^-12')
    print('  Uniform contraction constant < 1/20000')


def distance_checks():
    r = RADIUS*S
    check(r.denominator == 1, 'center and radius denominators incompatible')
    r_int = r.numerator
    min_d = None
    min_gap = None
    for u, v in combinations(range(len(CENTER)), 2):
        dx, dy = (CENTER[u][i] - CENTER[v][i] for i in (0, 1))
        d2 = dx*dx + dy*dy
        # Each coordinate difference changes by at most 2r in integer units.
        error = 4*r_int*(abs(dx) + abs(dy)) + 8*r_int*r_int
        lower = d2 - error
        min_d = lower if min_d is None else min(min_d, lower)
        if (u, v) not in EDGES:
            lower = abs(d2 - S*S) - error
            min_gap = lower if min_gap is None else min(min_gap, lower)
    check(Fraction(min_d, S*S) > Fraction(2, 10**5), 'separation too small')
    check(Fraction(min_gap, S*S) > Fraction(3, 10**4), 'unexpected unit distance')
    print('Every squared point separation exceeds 0.00002.')
    print('Every nonedge squared distance differs from 1 by more than 0.0003.')


if __name__ == '__main__':
    graph_checks()
    root_check()
    distance_checks()
    print('Verified 41 distinct points with exactly 79 unit-distance pairs.')
