import itertools

g6 = "T???C@?GC_B?@_p??T@cAAE_So@Q@AEGA_e?"
n = ord(g6[0]) - 63
bits = ''.join(format(ord(c)-63, '06b') for c in g6[1:])
vertex_pairs = ((i,j) for j in range(n) for i in range(j))
E = {pair for pair, flag in zip(vertex_pairs, bits) if flag == '1'}
assert n == 21 and len(E) == 40 and (2,18) in E
A = [set() for _ in range(n)]
for u,v in E:
    A[u].add(v)
    A[v].add(u)
cycles = [(0,2,8,11,12),(1,4,5,7,9),(3,6,10,15,14),(13,18,17,19,16)]
perm = list(range(n))
for orbit in cycles:
    for v,w in zip(orbit, orbit[1:]+orbit[:1]):
        perm[v] = w
assert {tuple(sorted((perm[v],perm[w]))) for v,w in E} == E
roots = (0,2,8,11,12)
assert A[20] == set(roots)
assert [sorted(A[r]-{20}) for r in roots] == [
    [7,10,13],[9,15,18],[1,14,17],[3,4,19],[5,6,16]]
leaves = set(range(21)) - {20} - set(roots)
assert all(len(A[t]&set(roots)) == 1 for t in leaves)
assert all(not (A[u]&A[v]) for u,v in E)
assert all(len(A[u]&A[v]) <= 1 for u,v in itertools.combinations(range(n),2))
H = E - {(2,18)}
c = [0,0,0,0,2,0,0,1,1,1,1,1,1,1,2,2,0,2,0,2,2]
assert all(c[u] != c[v] for u,v in H)
assert all(tuple(sorted((u,v))) in H for u,v in zip([1,13,15,6,19],[13,15,6,19,1]))
paths = [
    (set(), [1,13,15,6,19,1], [1,13,15,6,19,1]),
    ({0}, [3,15,6,14,18,4,16,9,17,3], [3,15,6,14,18,4,16,9,17,3]),
    ({0,2}, [6,15,13,1,19,6], [6,14,18,7,19,6]),
    ({0,8}, [6,14,10,3,15,6], [6,15,13,1,19,6])]
for S, chain0, chain2 in paths:
    for color, chain in [(0,chain0),(2,chain2)]:
        start = color
        for v,w in zip(chain,chain[1:]):
            assert w in A[v]
            palette = {0,1} if S & A[w] else {0,2}
            assert color in palette
            color, = palette - {color}
        assert chain[0] == chain[-1] and start != color
print("Verified graph6, 40 edges, automorphism, rooted colour lists, all forcing chains, and five-cycle.")
